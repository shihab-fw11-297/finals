import type { EntryEngineResult, TradeSignal } from "../entry-engine/types";
import {
  createStrategyResultCacheKey,
  getCachedStrategyResult,
  setCachedStrategyResult,
} from "../cache/strategy-result-cache";
import { calculateATR, generateV2Signals, selectMasterSignals } from "../v2-signal-engine";
import type { V2GoldmineInput } from "../v2-signal-engine/types";

export const CUSTOM_MULTI_STRATEGY_ID = "CUSTOM_MULTI_V2" as const;

export function runSelectedStrategy(strategyId: string, input: V2GoldmineInput): EntryEngineResult {
  const cacheKey = createStrategyResultCacheKey(strategyId, input);
  const cachedResult = getCachedStrategyResult(cacheKey);

  if (cachedResult) {
    return cachedResult;
  }

  return setCachedStrategyResult(cacheKey, generateV2Signals(strategyId, input));
}

export function runSelectedStrategies(strategyIds: string[], input: V2GoldmineInput): EntryEngineResult {
  const uniqueStrategyIds = [...new Set(strategyIds)].filter((strategyId) => strategyId !== "ALL_V2" && strategyId !== CUSTOM_MULTI_STRATEGY_ID);
  const cacheKey = createStrategyResultCacheKey(`${CUSTOM_MULTI_STRATEGY_ID}:${uniqueStrategyIds.join(",")}`, input);
  const cachedResult = getCachedStrategyResult(cacheKey);

  if (cachedResult) {
    return cachedResult;
  }

  if (uniqueStrategyIds.length === 0) {
    return setCachedStrategyResult(cacheKey, generateV2Signals("ALL_V2", input));
  }

  const results = uniqueStrategyIds.map((strategyId) => generateV2Signals(strategyId, input));
  const signals = results.flatMap((result) => result.signals).sort(signalOrder);
  const signalMap = new Map<string, TradeSignal>();
  for (const signal of signals) {
    signalMap.set(signal.id, signal);
  }

  const pendingCandidates = results.flatMap((result) => result.pendingCandidates);
  const candidateDebug = results.flatMap((result) => result.candidateDebug);
  const rejectedSetups = results.flatMap((result) => result.rejectedSetups);
  const closedCandles = input.candles.filter((candle) => candle.isClosed);
  const masterSelection = selectMasterSignals({
    rawSignals: signals,
    pendingCandidates,
    strategyDebugRows: candidateDebug,
    candles: closedCandles,
    timeframe: input.timeframe,
    mode: input.settings?.currentMode ?? input.settings?.mode ?? "normal",
    marketContext: input.context,
    session: input.context.session?.session,
    atr: calculateATR(closedCandles, 14),
  });

  const firstAudit = results[0].audit;
  const audit = {
    ...firstAudit,
    strategyId: CUSTOM_MULTI_STRATEGY_ID,
    totalCandlesScanned: Math.max(...results.map((result) => result.audit.totalCandlesScanned), 0),
    confirmedBuyCount: sum(results, (result) => result.audit.confirmedBuyCount),
    confirmedSellCount: sum(results, (result) => result.audit.confirmedSellCount),
    rejectedSetupCount: sum(results, (result) => result.audit.rejectedSetupCount),
    pendingConfirmationCount: sum(results, (result) => result.audit.pendingConfirmationCount),
    expiredCount: sum(results, (result) => result.audit.expiredCount),
    generationTimeMs: sum(results, (result) => result.audit.generationTimeMs),
    calculationTimeMs: sum(results, (result) => result.audit.calculationTimeMs),
    lastRejectionReason: results.find((result) => result.audit.lastRejectionReason)?.audit.lastRejectionReason ?? null,
    lastConfirmedSignal: signals.at(-1)?.id ?? null,
    topRejectionReasons: mergeTopRejectionReasons(results),
    lastFiveConfirmedSignals: signals.slice(-5).map((signal) => signal.id),
    lastCandidateDebug: candidateDebug.at(-1) ?? null,
    noSignalMessage: signals.length ? null : "No confirmed signals found for the selected custom strategy basket.",
    v2Goldmine: pickAudit(results, "v2Goldmine"),
    v2Breakout: pickAudit(results, "v2Breakout"),
    v2SilverBullet: pickAudit(results, "v2SilverBullet"),
    v2VwapEma: pickAudit(results, "v2VwapEma"),
    v2EmaTrendPullback: pickAudit(results, "v2EmaTrendPullback"),
    v2LiquiditySweepReversalPro: pickAudit(results, "v2LiquiditySweepReversalPro"),
    v2OrderBlockRetest: pickAudit(results, "v2OrderBlockRetest"),
    v2FvgContinuation: pickAudit(results, "v2FvgContinuation"),
    v2ProLiquidityConfluence: pickAudit(results, "v2ProLiquidityConfluence"),
    v2StockGuruSweepFvgOb: pickAudit(results, "v2StockGuruSweepFvgOb"),
    v2TjrSimpleStructurePullback: pickAudit(results, "v2TjrSimpleStructurePullback"),
    v2IctOteContinuation: pickAudit(results, "v2IctOteContinuation"),
    v2IctIfvgReversal: pickAudit(results, "v2IctIfvgReversal"),
  };

  return setCachedStrategyResult(cacheKey, {
    signals,
    activeSignals: signals,
    signalMap,
    pendingCandidates,
    candidateDebug,
    rejectedSetups,
    noTrade: signals.length ? null : {
      status: "NO_TRADE",
      checkedSetups: rejectedSetups.length + pendingCandidates.length,
      rejectionReasons: rejectedSetups.flatMap((setup) => setup.rejectionReasons),
      message: "No confirmed signals found for the selected custom strategy basket.",
      nearestPossibleSetup: null,
      requiredForSignal: ["A valid selected strategy setup", "Closed-candle confirmation"],
      timestamp: closedCandles.at(-1)?.timestamp ?? null,
    },
    audit,
    v2AsianRanges: results.flatMap((result) => result.v2AsianRanges ?? []),
    masterSelection,
  });
}

function signalOrder(left: TradeSignal, right: TradeSignal): number {
  return left.confirmedAtIndex - right.confirmedAtIndex || left.timestamp - right.timestamp || left.id.localeCompare(right.id);
}

function sum(results: EntryEngineResult[], select: (result: EntryEngineResult) => number): number {
  return results.reduce((total, result) => total + select(result), 0);
}

function mergeTopRejectionReasons(results: EntryEngineResult[]): Array<{ reason: string; count: number }> {
  const counts = new Map<string, number>();
  for (const result of results) {
    for (const item of result.audit.topRejectionReasons) {
      counts.set(item.reason, (counts.get(item.reason) ?? 0) + item.count);
    }
  }
  return [...counts.entries()]
    .map(([reason, count]) => ({ reason, count }))
    .sort((left, right) => right.count - left.count)
    .slice(0, 10);
}

function pickAudit<Key extends keyof EntryEngineResult["audit"]>(results: EntryEngineResult[], key: Key): EntryEngineResult["audit"][Key] | undefined {
  return results.find((result) => result.audit[key])?.audit[key];
}
