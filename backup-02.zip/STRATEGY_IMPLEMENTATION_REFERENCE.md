# XAUUSD V2 Strategy Implementation Reference

This document describes the XAUUSD V2 strategy modules implemented in this repository and how their signals are displayed in the chart app. It is an implementation reference only. It does not claim profitability and it is not trading advice.

## Current Signal Stack

The app has three signal layers:

1. Raw strategy engines generate independent `TradeSignal` objects from closed candles only.
2. `ALL_V2` runs all raw V2 strategies together and merges their confirmed signals.
3. `CUSTOM_MULTI_V2` runs a user-selected basket of one or more raw strategies and merges their confirmed signals.
4. `MASTER_SIGNAL_SELECTOR` ranks merged `ALL_V2` or `CUSTOM_MULTI_V2` raw signals, groups similar ideas, suppresses weaker duplicates, handles BUY/SELL conflicts, and returns final actionable master signals.

Raw strategies are preserved. The master layer does not delete or rewrite the raw signal list.

## Strategy Inventory

| Priority | Strategy ID | Label | Primary setup | Default/allowed timeframe | Normal threshold |
| ---: | --- | --- | --- | --- | --- |
| 1 | `STOCK_GURU_SWEEP_FVG_OB_ENGINE` | Stock Guru Sweep FVG OB Engine | Liquidity sweep -> reclaim -> displacement -> BOS/CHoCH -> FVG/OB zone retest | Default 5m; 1m/5m/15m allowed | Score 65, RR 1.5R |
| 2 | `PRO_LIQUIDITY_CONFLUENCE_ENGINE` | Pro Liquidity Confluence Engine | Sweep -> displacement -> MSS/CHoCH -> premium/discount zone retest | Default 5m; 1m/5m/15m allowed | 6/8 factors, RR 1.5R |
| 3 | `ICT_IFVG_REVERSAL_ENGINE` | ICT IFVG Reversal Engine | FVG inversion -> zone retest -> reversal confirmation | Default 5m; 1m/5m/15m allowed | Score 62, RR 1.5R |
| 4 | `ICT_OTE_CONTINUATION_ENGINE` | ICT OTE Continuation Engine | Impulse/BOS -> OTE 62-79 retracement -> continuation confirmation | Default 5m; 1m/5m/15m allowed | 6/8 factors, RR 1.5R |
| 5 | `ICT_SILVER_BULLET` | ICT Silver Bullet | Killzone sweep -> reclaim -> displacement/MSS -> FVG retest | Default 1m; 1m/5m allowed | Score 65, RR 1.5R |
| 6 | `FVG_CONTINUATION_ENTRY` | FVG Continuation Entry | Displacement/BOS -> same-direction FVG -> retest -> confirmation | Default 5m; 1m/5m/15m allowed | Score 62, RR 1.5R |
| 7 | `ORDER_BLOCK_RETEST_CONFIRMATION` | Order Block Retest Confirmation | Displacement/BOS -> order block -> retest -> confirmation | Default 5m | Score 62, RR 1.5R |
| 8 | `LIQUIDITY_SWEEP_REVERSAL_PRO` | Liquidity Sweep Reversal Pro | Liquidity sweep -> reclaim -> reversal confirmation | Default 5m | Score 60, RR 1.5R |
| 9 | `GOLDMINE_ASIAN_SWEEP_REVERSAL` | Goldmine Asian Sweep Reversal | Asian range sweep -> rejection -> MSS/displacement confirmation | Chart timeframe | Score 55, RR 1.5R |
| 10 | `ASIAN_RANGE_BREAKOUT_RETEST` | Asian Range Breakout Retest | Asian range breakout -> retest -> continuation confirmation | Chart timeframe | Score 60, RR 1.5R |
| 11 | `TJR_SIMPLE_STRUCTURE_PULLBACK_ENGINE` | TJR Simple Structure Pullback Engine | Structure break/CHoCH -> FVG/OB/EMA zone pullback -> confirmation | Default 5m; 1m/5m/15m allowed | Score 60, RR 1.5R |
| 12 | `EMA_TREND_PULLBACK` | EMA Trend Pullback | EMA stack trend -> EMA20/50 pullback -> continuation confirmation | Default 5m | Score 58, RR 1.5R |
| 13 | `VWAP_EMA_REGIME_PULLBACK` | VWAP EMA Regime Pullback | VWAP/EMA regime -> EMA pullback -> continuation confirmation | 5m | Score 60, RR 1.5R |
| - | `ALL_V2` | All V2 Strategies | Runs all thirteen strategy engines and merges raw output | Selected chart timeframe | Per strategy, then master selector |
| - | `CUSTOM_MULTI_V2` | Custom Multi Strategy | Runs any selected strategy engines and merges raw output | Selected chart timeframe | Per selected strategy, then master selector |
| - | `MASTER_SIGNAL_SELECTOR` | Master Signal Selector | Ranks and filters merged `ALL_V2` or `CUSTOM_MULTI_V2` raw output | Same as selected chart timeframe | Score 65, RR 1.5R in normal mode |

## Shared Signal Rules

- Only closed candles are scanned. Forming candles are ignored.
- BUY and SELL logic is mirrored in every strategy.
- Entry is the confirmation candle close unless a strategy explicitly stores a different immutable entry.
- Stop loss, take profit, RR, score, confirmation index, and evidence are frozen when the signal is created.
- A valid BUY must have `entryPrice > stopLoss` and `takeProfit > entryPrice`.
- A valid SELL must have `entryPrice < stopLoss` and `takeProfit < entryPrice`.
- `RR = abs(takeProfit - entryPrice) / abs(entryPrice - stopLoss)`.
- Signals below the strategy RR threshold are rejected before they reach the chart.
- `noRepaintProof` stores the evidence indexes used to create the signal.

## 1. Stock Guru Sweep FVG OB Engine

Source: `lib/v2-signal-engine/stock-guru-sweep-fvg-ob-engine.ts`

This is the highest-priority raw strategy in the master selector.

Main sequence:

1. Find liquidity from swings, equal highs/lows, previous session levels, round numbers, or recent range extremes.
2. BUY sweeps sell-side liquidity and reclaims upward. SELL sweeps buy-side liquidity and reclaims downward.
3. Reclaim must happen within two candles.
4. Displacement must follow within five candles.
5. BOS or wick CHoCH must follow displacement within five candles.
6. Build an entry zone from FVG, order block, or FVG/OB overlap.
7. Wait for a retest of that zone.
8. Confirm with directional close, body quality, and RR validation.

Normal mode thresholds:

- Sweep distance: `0.04-1.5 ATR`.
- Displacement: at least `0.40 ATR`, body ratio `0.55`, close position `0.65`.
- FVG minimum size: `0.08 ATR`.
- Retest window: 12 candles.
- Confirmation body ratio: `0.45`.
- Minimum score: 65.
- Minimum RR: 1.5R.
- Maximum SL: `3.0 ATR`.

Signal output:

- BUY marker appears below the candle.
- SELL marker appears above the candle.
- Signal details include the selected zone, sweep evidence, structure break, entry, SL, TP, RR, score, and mode.

## 2. Pro Liquidity Confluence Engine

Source: `lib/v2-signal-engine/pro-liquidity-confluence-engine.ts`

Main sequence:

1. Detect a confirmed liquidity level from recent swing highs/lows or repeated equal levels.
2. BUY sweeps SSL; SELL sweeps BSL.
3. Price must reclaim the liquidity level.
4. Require directional displacement.
5. Require MSS or CHoCH.
6. Build a zone from FVG, order block, displacement 50%, or OTE.
7. Wait for zone retest.
8. Confirm with a directional candle and valid RR.

Normal mode thresholds:

- Required factor score: 6/8.
- Minimum RR: 1.5R.
- Maximum SL: `4.5 ATR`.
- Zone retest window: 12 candles.
- Confirmation body ratio: `0.40`.

Eight scoring factors:

- Bias alignment.
- Valid sweep.
- Strong displacement.
- MSS/CHoCH.
- Entry zone.
- Confirmation.
- Valid RR.
- Session/volatility.

## 3. ICT IFVG Reversal Engine

Source: `lib/v2-signal-engine/ict-ifvg-reversal.ts`

Main sequence:

1. Detect an original FVG.
2. Wait for price to invert through the FVG.
3. Treat the inverted FVG as a reversal zone.
4. Wait for retest of the inverted zone.
5. Confirm with directional candle quality and structure behavior.
6. Validate RR, stop size, score, and session warning rules.

Normal mode thresholds:

- FVG size: `0.08-2.0 ATR`.
- Inversion buffer: `0.04 ATR`.
- Retest deadline: 15 candles.
- Confirmation range: `0.25 ATR`.
- Confirmation body ratio: `0.42`.
- Confirmation close position: `0.60`.
- Minimum score: 62.
- Minimum RR: 1.5R.
- Maximum SL: `2.8 ATR`.

Direction rule:

- A bearish FVG that later inverts upward can create a BUY IFVG reversal.
- A bullish FVG that later inverts downward can create a SELL IFVG reversal.

## 4. ICT OTE Continuation Engine

Source: `lib/v2-signal-engine/ict-ote-continuation-engine.ts`

Main sequence:

1. Detect a clean impulse leg.
2. Confirm BOS/MSS/CHoCH after the impulse.
3. Optionally detect pre-impulse liquidity sweep.
4. Build OTE retracement zone between 0.62 and 0.79.
5. Add confluence from FVG, liquidity, EMA, VWAP, or order block boundary.
6. Wait for OTE touch.
7. Confirm continuation candle.
8. Validate RR and stop size.

Normal mode thresholds:

- Minimum impulse range: `1.20 ATR`.
- Minimum displacement range: `0.55 ATR`.
- Average range multiple: `1.10`.
- OTE touch window: 20 candles.
- Confirmation window: 4 candles.
- Required factor score: 6/8.
- Minimum RR: 1.5R.
- Maximum SL: `4.0 ATR`.

Direction rule:

- BUY uses a bullish impulse and waits for a pullback into the bullish OTE discount zone.
- SELL uses a bearish impulse and waits for a pullback into the bearish OTE premium zone.

## 5. ICT Silver Bullet

Source: `lib/v2-signal-engine/ict-silver-bullet.ts`

Scanned killzones are based on `America/New_York` time:

- London Silver Bullet: 03:00-04:00.
- New York AM Silver Bullet: 10:00-11:00.
- New York PM Silver Bullet: 14:00-15:00.

Main sequence:

1. Detect swing, equal high/low, previous session, or round-number liquidity.
2. Sweep liquidity by `0.05-1.25 ATR`.
3. Reclaim on the same or next candle.
4. Require displacement.
5. Require MSS, with CHoCH accepted by config.
6. Create same-direction FVG.
7. Retest the FVG.
8. Confirm before the killzone ends.

Normal mode thresholds:

- Minimum score: 65.
- Minimum RR: 1.5R.
- Maximum SL: `2.8 ATR`.
- Maximum one signal per killzone.
- Maximum three signals per day.

## 6. FVG Continuation Entry

Source: `lib/v2-signal-engine/fvg-continuation-entry.ts`

Main sequence:

1. Detect displacement with directional close.
2. Require BOS by close; wick CHoCH is allowed.
3. Detect same-direction three-candle FVG.
4. Wait for FVG retest.
5. Confirm with candle body, range, close position, and midpoint defense.
6. Validate RR and stop size.

Normal mode thresholds:

- Displacement range: `0.40 ATR`.
- Body ratio: `0.55`.
- Close position: `0.65`.
- FVG size: `0.08-2.0 ATR`.
- FVG age: max 40 candles.
- Retest deadline: 12 candles.
- Confirmation window: 4 candles.
- Minimum score: 62.
- Minimum RR: 1.5R.
- Maximum SL: `2.8 ATR`.

Bonuses:

- Liquidity sweep bonus.
- Nearby order block bonus.
- EMA trend alignment bonus.

## 7. Order Block Retest Confirmation

Source: `lib/v2-signal-engine/order-block-retest.ts`

Main sequence:

1. Detect displacement through recent structure.
2. Search backward for the last opposite candle.
3. Build an order block zone.
4. Wait for retest.
5. Confirm rejection from the order block.
6. Validate RR and stop size.

Normal mode thresholds:

- Displacement range: `0.40 ATR`.
- Body ratio: `0.55`.
- Order block size: `0.10-1.50 ATR`.
- Maximum order block age: 80 candles.
- Retest deadline: 40 candles.
- Confirmation body ratio: `0.45`.
- Minimum score: 62.
- Minimum RR: 1.5R.
- Maximum SL: `2.8 ATR`.

Bonuses:

- Nearby FVG.
- Pre-displacement liquidity sweep.

## 8. Liquidity Sweep Reversal Pro

Source: `lib/v2-signal-engine/liquidity-sweep-reversal-pro.ts`

Main sequence:

1. Detect liquidity from swings, equal highs/lows, previous day, current session, or XAUUSD round numbers.
2. BUY sweeps SSL; SELL sweeps BSL.
3. Reclaim on the same or next candle.
4. Confirm within the configured window.
5. MSS and FVG are bonus confluence, not hard requirements.

Normal mode thresholds:

- Sweep distance: `0.05-1.2 ATR`.
- Confirmation window: 4 candles.
- Confirmation body ratio: `0.45`.
- Confirmation close position: `0.60`.
- Minimum score: 60.
- Minimum RR: 1.5R.
- Maximum SL: `2.8 ATR`.
- Maximum six signals per day.

## 9. Goldmine Asian Sweep Reversal

Source: `lib/v2-signal-engine/goldmine-asian-sweep.ts`

Main sequence:

1. Build Asian range from UTC 00:00-07:00.
2. Scan London and New York windows.
3. BUY sweeps below Asian low.
4. SELL sweeps above Asian high.
5. Require close back inside the range and rejection wick quality.
6. Require MSS or displacement confirmation.
7. Validate RR using midpoint, opposite range boundary, liquidity target, or fixed RR fallback.

Normal thresholds:

- Minimum score: 55.
- Minimum RR: 1.5R.
- Confirmation window: 6 candles.
- Sweep rejection wick ratio: around `0.24`.
- Maximum three signals per day.

Session defaults:

- Asian: 00:00-07:00 UTC.
- London: 07:00-11:00 UTC.
- New York: 12:00-16:00 UTC.

The UI allows these session hours to be changed in the Strategy Activation panel.

## 10. Asian Range Breakout Retest

Source: `lib/v2-signal-engine/asian-breakout-retest.ts`

Main sequence:

1. Build the same Asian range used by Goldmine.
2. BUY closes above Asian high plus ATR buffer.
3. SELL closes below Asian low minus ATR buffer.
4. Wait for retest of the broken range boundary.
5. Confirm continuation away from the level.
6. Validate RR using measured move, liquidity target, or fixed RR fallback.

Normal thresholds:

- Breakout close buffer: `0.05 ATR`.
- Breakout body ratio: `0.45`.
- Retest tolerance: `0.15 ATR`.
- Retest window: 8 candles.
- Confirmation window: 6 candles.
- Minimum score: 60.
- Minimum RR: 1.5R.
- Maximum two signals per day.

## 11. TJR Simple Structure Pullback Engine

Source: `lib/v2-signal-engine/tjr-simple-structure-pullback-engine.ts`

This module is designed to be easier to read and debug than the heavier pro engines.

Main sequence:

1. Detect market structure: HH/HL, LH/LL, range, or transition.
2. Detect BOS for trend continuation or CHoCH for reversal.
3. Build a pullback zone from FVG, order block, EMA zone, or structure zone.
4. Wait for a retest of the zone.
5. Confirm with candle body, close position, rejection, and risk validation.
6. Reject very choppy or low-quality structure when thresholds are not met.

Normal mode thresholds:

- Retest window: 14 candles.
- Confirmation body ratio: `0.40`.
- Minimum confirmation range: `0.20 ATR`.
- Minimum score: 60.
- Minimum RR: 1.5R.
- Maximum SL: `3.0 ATR`.
- Maximum three signals per session.
- Maximum six signals per day.

Models:

- `TREND_CONTINUATION` for pullbacks in the direction of structure.
- `CHOCH_REVERSAL` for cleaner reversal cases after a change of character.

## 12. EMA Trend Pullback

Source: `lib/v2-signal-engine/ema-trend-pullback.ts`

Main sequence:

1. Detect EMA trend stack.
2. BUY requires EMA20 > EMA50 > EMA200 and price above trend support.
3. SELL requires EMA20 < EMA50 < EMA200 and price below trend resistance.
4. Wait for pullback into EMA20/50 zone.
5. Confirm continuation away from the zone.
6. Validate RR and stop size.

Normal thresholds:

- Trend strength: `0.20 ATR`.
- Pullback zone buffer: `0.30 ATR`.
- Max pullback candles: 8.
- Confirmation body ratio: `0.45`.
- Confirmation close position: `0.60`.
- Minimum score: 58.
- Minimum RR: 1.5R.
- Maximum SL: `2.5 ATR`.

This strategy requires London/New York/overlap session.

## 13. VWAP EMA Regime Pullback

Source: `lib/v2-signal-engine/vwap-ema-regime-pullback.ts`

Main sequence:

1. Detect VWAP and EMA200 regime.
2. BUY requires close above session VWAP and EMA200, plus EMA20 > EMA50.
3. SELL requires close below session VWAP and EMA200, plus EMA20 < EMA50.
4. Wait for pullback into EMA20/50 zone.
5. Confirm continuation.
6. Validate RR and stop size.

Normal thresholds:

- VWAP distance: `0.10-2.50 ATR`.
- Pullback zone buffer: `0.25 ATR`.
- Max pullback candles: 8.
- Confirmation body ratio: `0.45`.
- Confirmation close position: `0.60`.
- Minimum score: 60.
- Minimum RR: 1.5R.
- Maximum SL: `2.5 ATR`.

Session windows are based on `America/New_York`:

- London: 03:00-06:00.
- New York AM: 08:30-11:30.
- Overlap: 08:00-11:00.

## ALL_V2 Behavior

Source: `lib/v2-signal-engine/coordinator.ts`

`ALL_V2` runs all thirteen raw strategy engines:

- `GOLDMINE_ASIAN_SWEEP_REVERSAL`
- `ASIAN_RANGE_BREAKOUT_RETEST`
- `ICT_SILVER_BULLET`
- `VWAP_EMA_REGIME_PULLBACK`
- `EMA_TREND_PULLBACK`
- `LIQUIDITY_SWEEP_REVERSAL_PRO`
- `ORDER_BLOCK_RETEST_CONFIRMATION`
- `FVG_CONTINUATION_ENTRY`
- `PRO_LIQUIDITY_CONFLUENCE_ENGINE`
- `STOCK_GURU_SWEEP_FVG_OB_ENGINE`
- `TJR_SIMPLE_STRUCTURE_PULLBACK_ENGINE`
- `ICT_OTE_CONTINUATION_ENGINE`
- `ICT_IFVG_REVERSAL_ENGINE`

It merges:

- confirmed raw signals,
- active signals,
- pending candidates,
- rejected setups,
- debug rows,
- audit counts,
- Asian ranges.

After the merge, `ALL_V2` calls `selectMasterSignals(...)` and stores the result in `EntryEngineResult.masterSelection`.

## CUSTOM_MULTI_V2 Behavior

Source: `lib/strategy-runner/run-selected-strategy.ts`

`CUSTOM_MULTI_V2` is the user-selected multi-strategy basket mode. It is useful when you want more than one engine active, but do not want the noise or scan cost of running every V2 strategy.

Behavior:

- The UI requires at least one selected strategy and allows selecting any number of raw strategies.
- Each selected strategy runs independently with its own rules.
- Confirmed raw signals are merged and sorted by confirmation index.
- Pending candidates, debug rows, rejected setups, Asian ranges, and audit data are merged.
- The merged raw result is passed into `MASTER_SIGNAL_SELECTOR`.
- Raw, Master, and Both display modes work the same way as `ALL_V2`.

## Master Signal Selector

Source: `lib/v2-signal-engine/master-signal-selector.ts`

The master selector is only applied to `ALL_V2`.
It is also applied to `CUSTOM_MULTI_V2` when a custom basket is selected in the UI.

What it does:

1. Validates raw signals for entry/SL/TP direction, RR, stop width, closed-candle proof, and no-repaint proof.
2. Groups same-direction signals that appear near the same time and price.
3. Scores every candidate using strategy score, strategy priority, confluence, RR quality, market context, session quality, stop quality, confirmation quality, bonuses, and penalties.
4. Selects the best signal from each same-direction group.
5. Suppresses weaker duplicate ideas.
6. Detects close BUY/SELL conflicts.
7. Returns `NO_TRADE` for unresolved opposite-direction conflicts.
8. Applies cooldown and max-trade limits.
9. Freezes the final master signal levels and proof.

Normal master thresholds:

- Minimum master score: 65.
- Minimum RR: 1.5R.
- Default cooldown: 10 candles on 1m, 6 candles on 5m, 4 candles on 15m.
- Grouping window: 5 candles on 1m, 4 candles on 5m, 3 candles on 15m.
- Price grouping threshold: max of `0.35 ATR` and `35%` of signal risk.

Master priority order:

1. `STOCK_GURU_SWEEP_FVG_OB_ENGINE`
2. `PRO_LIQUIDITY_CONFLUENCE_ENGINE`
3. `ICT_IFVG_REVERSAL_ENGINE`
4. `ICT_OTE_CONTINUATION_ENGINE`
5. `ICT_SILVER_BULLET`
6. `FVG_CONTINUATION_ENTRY`
7. `ORDER_BLOCK_RETEST_CONFIRMATION`
8. `LIQUIDITY_SWEEP_REVERSAL_PRO`
9. `GOLDMINE_ASIAN_SWEEP_REVERSAL`
10. `ASIAN_RANGE_BREAKOUT_RETEST`
11. `TJR_SIMPLE_STRUCTURE_PULLBACK_ENGINE`
12. `EMA_TREND_PULLBACK`
13. `VWAP_EMA_REGIME_PULLBACK`

Important no-repaint behavior:

- Same-candle signals can compete before the master signal is frozen.
- Later same-direction signals inside the group are stored as post-entry confluence.
- Later confluence never changes the original master entry, SL, TP, RR, selected strategy, or master score.

## How To Show Signals In The App

1. Start the app:

```bash
npm run dev
```

2. Open:

```text
http://localhost:3015
```

3. In the top form, choose:

- `Symbol`: normally `XAUUSD`.
- `Timeframe`: `1m`, `5m`, or `15m` are best supported by the V2 strategies.
- `Start date` and `End date`.

4. Click `Fetch`.

5. In `Strategy Activation`, enable `Active`.

6. Choose a strategy from the `Strategy` dropdown.

7. Enable `Markers`.

8. Read signals on the chart and in the tables below the chart.

## How To Show Master Signals

Master signal display is available when the selected strategy is `ALL_V2` or `Custom Multi Strategy`.

Steps:

1. Enable `Active`.
2. Select `ALL_V2` or `Custom Multi Strategy` in the `Strategy` dropdown.
3. Enable `Markers`.
4. If using `Custom Multi Strategy`, choose any strategies in `Custom strategy basket`.
5. Use `Signal display`:

| Display mode | What appears |
| --- | --- |
| `Raw` | Every raw strategy signal generated by `ALL_V2`. This is useful for debugging why many strategies fired. |
| `Master` | Only final master-selected signals. This is the default for `ALL_V2`. |
| `Both` | Final master signals plus suppressed raw signals, so you can see what was filtered out. |

## How To Run Multiple Strategies Together

1. Enable `Active`.
2. Select `Custom Multi Strategy`.
3. In `Custom strategy basket`, tick the strategies you want.
4. Keep at least one selected. The UI allows selecting all raw strategies if desired.
5. Enable `Markers`.
6. Use `Signal display`:

- `Raw` shows every signal from the selected strategy basket.
- `Master` shows only the best final selected signals from that basket.
- `Both` shows final master signals plus the raw signals that were suppressed.

Good example baskets:

- `Stock Guru Sweep FVG OB Engine` + `Pro Liquidity Confluence Engine` + `FVG Continuation Entry`.
- `ICT IFVG Reversal Engine` + `ICT OTE Continuation Engine` + `ICT Silver Bullet`.
- `Asian Range Breakout Retest` + `Goldmine Asian Sweep Reversal`.

## Chart Marker Meaning

Raw strategy signals:

- BUY appears below the candle.
- SELL appears above the candle.
- Entry, SL, TP1, TP2, TP3, invalidation, and strategy-specific evidence lines are drawn when available.

Master signals:

- Master BUY/SELL markers are larger and gold.
- Marker text includes `MASTER BUY` or `MASTER SELL`, confluence count, and master score.
- Tooltip shows selected strategy, source strategies, confluence count, master score, confidence, entry, SL, TP, RR, and selection reason.

Suppressed raw signals in `Both` mode:

- Suppressed markers are smaller and gray.
- Tooltip shows that the signal was suppressed and why.
- Suppressed signals remain visible only for explanation; they are not final actionable master signals.

## Panels And Tables

When a strategy is active:

- `Master Signal Selector` panel appears for `ALL_V2` and summarizes raw count, groups, final signals, suppressed signals, conflicts, and selected master trades.
- `Signal Debug Panel` shows strategy audit rows, rejected setups, pending confirmations, and master debug information.
- `Signal History Table` lists displayed signals. Master rows show `MASTER_SIGNAL_SELECTOR`, selected strategy, master score, confidence, and reason.
- Performance panel shows current visible signal count, pending count, rejected count, and scan timing in development.

## Programmatic Usage

Run one strategy:

```ts
import { generateV2Signals } from "./lib/v2-signal-engine/coordinator";

const result = generateV2Signals("FVG_CONTINUATION_ENTRY", input);
console.log(result.signals);
```

Run all strategies with master selection:

```ts
const result = generateV2Signals("ALL_V2", input);

const rawSignals = result.signals;
const masterSignals = result.masterSelection?.finalSignals ?? [];
const suppressed = result.masterSelection?.suppressedSignals ?? [];
```

Run a custom multi-strategy basket:

```ts
import { runSelectedStrategies } from "./lib/strategy-runner/run-selected-strategy";

const result = runSelectedStrategies([
  "STOCK_GURU_SWEEP_FVG_OB_ENGINE",
  "PRO_LIQUIDITY_CONFLUENCE_ENGINE",
  "FVG_CONTINUATION_ENTRY",
], input);
```

Choose chart display signals exactly like the UI:

```ts
import { getMasterDisplaySignals } from "./lib/v2-signal-engine/master-signal-selector";

const displaySignals = result.masterSelection
  ? getMasterDisplaySignals(result.masterSelection, "MASTER")
  : result.signals;
```

Available display modes are `"RAW"`, `"MASTER"`, and `"BOTH"`.

## Why You May See Only BUY Or Only SELL

Seeing only BUY or only SELL can be valid if the selected candle range only confirms one side. The engines do not force both directions.

Common reasons:

- The market structure and context are one-sided.
- SELL setups were detected but failed RR, stop width, session, confirmation, or score rules.
- In `ALL_V2` or `Custom Multi Strategy` Master mode, raw SELL signals may be suppressed by stronger BUY groups or marked `NO_TRADE` in conflict.
- A short date range may not include a full Asian range, retest, or confirmation window.
- `Markers` may be off, or the selected strategy may be a single raw strategy instead of `ALL_V2`.

To diagnose:

1. Select `ALL_V2`.
2. Set `Signal display` to `Raw`.
3. Enable `Markers`.
4. Check the `Signal Debug Panel` for rejected SELL setups.
5. Switch to `Both` to see whether SELL was suppressed by the master selector.

For a smaller check, select `Custom Multi Strategy` and run only the strategies you trust most.

## No-Repaint Contract

- Strategies only use candles with `isClosed === true`.
- A signal is timestamped at its confirmation candle.
- Entry, SL, TP, RR, score, and selected strategy are immutable after confirmation.
- Master signals freeze their own `masterNoRepaintProof`.
- Future candles may add later confluence, but they must not modify the original master trade levels.

Tests cover raw strategy behavior, master BUY/SELL grouping, duplicate suppression, conflict handling, display modes, and no-repaint behavior.
