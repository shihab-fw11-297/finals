import type { EntryEngineResult } from "../entry-engine/types";
import {
  createStrategyResultCacheKey,
  getCachedStrategyResult,
  setCachedStrategyResult,
} from "../cache/strategy-result-cache";
import { generateV2Signals } from "../v2-signal-engine";
import type { V2GoldmineInput } from "../v2-signal-engine/types";

export function runSelectedStrategy(strategyId: string, input: V2GoldmineInput): EntryEngineResult {
  const cacheKey = createStrategyResultCacheKey(strategyId, input);
  const cachedResult = getCachedStrategyResult(cacheKey);

  if (cachedResult) {
    return cachedResult;
  }

  return setCachedStrategyResult(cacheKey, generateV2Signals(strategyId, input));
}
