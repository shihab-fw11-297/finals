import type { Candle } from "../candles/types";
import type {
  EntryEngineResult,
  RejectedSetup,
  SignalCandidateDebug,
  SignalRejectionCode,
  SignalScoreBreakdown,
  TradeSignal,
} from "../entry-engine/types";
import type { TradingSession } from "../market-context/types";
import {
  ACTIVE_SIGNAL_ENGINE,
  ORDER_BLOCK_RETEST_CONFIG as CONFIG,
  ORDER_BLOCK_RETEST_STRATEGY_ID,
  ORDER_BLOCK_RETEST_STRATEGY_LABEL,
} from "./config";
import { calculateATR, detectSwingHigh, detectSwingLow, zonedDateParts } from "./indicators";
import type { V2GoldmineInput } from "./types";

type Direction = "BUY" | "SELL";
type Stage =
  | "STRUCTURE_BREAK_DETECTED"
  | "ORDER_BLOCK_CREATED"
  | "WAITING_RETEST"
  | "ORDER_BLOCK_RETESTED"
  | "WAITING_CONFIRMATION"
  | "CONFIRMED_SIGNAL"
  | "REJECTED"
  | "EXPIRED";
type OrderBlockType = "BULLISH_OB" | "BEARISH_OB";

type Displacement = {
  direction: Direction;
  candleIndex: number;
  bodyRatio: number;
  rangeAtrMultiple: number;
  structureLevel: number;
};

type OrderBlock = {
  type: OrderBlockType;
  direction: Direction;
  createdAt: number;
  candleIndex: number;
  displacementIndex: number;
  top: number;
  bottom: number;
  midpoint: number;
  sizeAtr: number;
  structureLevel: number;
  displacementBodyRatio: number;
  displacementRangeAtr: number;
  hasFvg: boolean;
  hasLiquiditySweep: boolean;
};

type Retest = {
  candleIndex: number;
  retestPrice: number;
  retestDepthPercent: number;
};

type ScoreParts = {
  structureBreakQuality: number;
  displacementQuality: number;
  orderBlockQuality: number;
  retestQuality: number;
  confirmationQuality: number;
  rrQuality: number;
};

const resultCache = new Map<string, EntryEngineResult>();
const SESSION_TIMEZONE = "America/New_York";

export function clearOrderBlockRetestCache(): void {
  resultCache.clear();
}

export function generateOrderBlockRetestSignals(input: V2GoldmineInput): EntryEngineResult {
  const started = performance.now();
  const candles = input.candles.filter((candle) => candle.isClosed);
  const key = `${ORDER_BLOCK_RETEST_STRATEGY_ID}:${input.symbol}:${input.timeframe}:${candles.length}:${candles.at(-1)?.timestamp ?? 0}:${input.settings?.maxRiskAmount ?? 100}`;
  const cached = resultCache.get(key);
  if (cached) return cloneResult(cached, "hit");

  const atr = calculateATR(candles, CONFIG.atrPeriod);
  const signals: TradeSignal[] = [];
  const pendingCandidates: SignalCandidateDebug[] = [];
  const candidateDebug: SignalCandidateDebug[] = [];
  const rejectedSetups: RejectedSetup[] = [];
  const rejectionCounts = new Map<string, number>();
  const sessionSignalCounts = new Map<string, number>();
  const daySignalCounts = new Map<string, number>();
  let structureBreaksFound = 0;
  let orderBlocksCreated = 0;
  let validOrderBlocks = 0;
  let retestsFound = 0;
  let confirmationCandlesFound = 0;
  let expiredSetups = 0;

  if (candles.length < CONFIG.atrPeriod + CONFIG.swingLookback * 2 + 2) {
    increment(rejectionCounts, "INSUFFICIENT_CANDLES");
  }

  const firstIndex = Math.max(CONFIG.atrPeriod, CONFIG.swingLookback * 2 + 1);
  for (let index = firstIndex; index < candles.length; index++) {
    const currentAtr = atr[index];
    if (!currentAtr || !Number.isFinite(currentAtr)) {
      increment(rejectionCounts, "INSUFFICIENT_CANDLES");
      continue;
    }

    const displacement = detectDisplacement(candles, index, currentAtr);
    if (!displacement) continue;
    structureBreaksFound++;

    const orderBlock = createOrderBlock(candles, atr, displacement);
    if (!orderBlock) {
      addRejection(`ob:${candles[index].timestamp}:${displacement.direction}:NO_VALID_ORDER_BLOCK`, "NO_VALID_ORDER_BLOCK", displacement.direction, index, "REJECTED");
      continue;
    }
    orderBlocksCreated++;

    if (orderBlock.sizeAtr < CONFIG.orderBlockMinSizeAtr) {
      addRejection(setupId(orderBlock), "ORDER_BLOCK_TOO_SMALL", orderBlock.direction, orderBlock.candleIndex, "REJECTED");
      continue;
    }
    if (orderBlock.sizeAtr > CONFIG.orderBlockMaxSizeAtr) {
      addRejection(setupId(orderBlock), "ORDER_BLOCK_TOO_LARGE", orderBlock.direction, orderBlock.candleIndex, "REJECTED");
      continue;
    }
    validOrderBlocks++;

    const evaluated = evaluateOrderBlock(orderBlock, index);
    if (evaluated.confirmedIndex !== null) {
      index = Math.max(index, evaluated.confirmedIndex);
    }
  }

  function evaluateOrderBlock(orderBlock: OrderBlock, displacementIndex: number): { confirmedIndex: number | null } {
    const maxIndex = Math.min(
      candles.length - 1,
      displacementIndex + CONFIG.maxRetestCandles,
      orderBlock.candleIndex + CONFIG.orderBlockMaxAgeCandles,
    );
    let retest: Retest | null = null;
    let invalidated = false;

    for (let check = displacementIndex + 1; check <= maxIndex; check++) {
      const checkAtr = atr[check] ?? atr[displacementIndex];
      if (!checkAtr) continue;
      if (!retest && orderBlockInvalidated(candles[check], orderBlock, checkAtr)) {
        invalidated = true;
        addRejection(setupId(orderBlock), "ORDER_BLOCK_INVALIDATED", orderBlock.direction, check, "REJECTED");
        break;
      }
      if (touchesOrderBlock(candles[check], orderBlock, checkAtr)) {
        retest = {
          candleIndex: check,
          retestPrice: orderBlock.direction === "BUY"
            ? Math.max(orderBlock.bottom, Math.min(candles[check].low, orderBlock.top))
            : Math.max(orderBlock.bottom, Math.min(candles[check].high, orderBlock.top)),
          retestDepthPercent: retestDepth(candles[check], orderBlock),
        };
        retestsFound++;
        if (orderBlockInvalidated(candles[check], orderBlock, checkAtr)) {
          invalidated = true;
          addRejection(setupId(orderBlock), "ORDER_BLOCK_INVALIDATED", orderBlock.direction, check, "REJECTED");
        }
        break;
      }
    }

    if (invalidated) return { confirmedIndex: null };

    if (!retest) {
      const age = candles.length - 1 - orderBlock.candleIndex;
      const waiting = candles.length - 1 < maxIndex && age < CONFIG.orderBlockMaxAgeCandles;
      if (waiting) {
        const debug = makeDebug(setupId(orderBlock), orderBlock.direction, "PENDING_CONFIRMATION", "NO_RETEST", Math.max(0, maxIndex - (candles.length - 1)), "WAITING_RETEST");
        candidateDebug.push(debug);
        pendingCandidates.push(debug);
      } else {
        expiredSetups++;
        const code: SignalRejectionCode = age >= CONFIG.orderBlockMaxAgeCandles ? "ORDER_BLOCK_EXPIRED" : "RETEST_EXPIRED";
        increment(rejectionCounts, code);
        rejectedSetups.push(toRejected(setupId(orderBlock), orderBlock.direction, Math.min(maxIndex, candles.length - 1), code, makeDebug(setupId(orderBlock), orderBlock.direction, "EXPIRED_CONFIRMATION", code, 0, "EXPIRED")));
      }
      return { confirmedIndex: null };
    }

    let confirmationIndex = -1;
    let weakConfirmation = false;
    for (let check = retest.candleIndex + 1; check <= maxIndex; check++) {
      const checkAtr = atr[check] ?? atr[displacementIndex];
      if (!checkAtr) continue;
      if (orderBlockInvalidated(candles[check], orderBlock, checkAtr)) {
        addRejection(setupId(orderBlock), "ORDER_BLOCK_INVALIDATED", orderBlock.direction, check, "REJECTED");
        return { confirmedIndex: null };
      }
      if (isConfirmation(candles[check], checkAtr, orderBlock.direction)) {
        confirmationIndex = check;
        break;
      }
      if (isDirectionalCandle(candles[check], orderBlock.direction)) weakConfirmation = true;
    }

    if (confirmationIndex < 0) {
      const waiting = candles.length - 1 < maxIndex;
      const debug = makeDebug(
        setupId(orderBlock),
        orderBlock.direction,
        waiting ? "PENDING_CONFIRMATION" : "EXPIRED_CONFIRMATION",
        waiting ? "WEAK_CONFIRMATION_CANDLE" : weakConfirmation ? "WEAK_CONFIRMATION_CANDLE" : "RETEST_EXPIRED",
        Math.max(0, maxIndex - (candles.length - 1)),
        waiting ? "WAITING_CONFIRMATION" : "EXPIRED",
      );
      candidateDebug.push(debug);
      if (waiting) {
        pendingCandidates.push(debug);
      } else {
        expiredSetups++;
        const code: SignalRejectionCode = weakConfirmation ? "WEAK_CONFIRMATION_CANDLE" : "RETEST_EXPIRED";
        increment(rejectionCounts, code);
        rejectedSetups.push(toRejected(setupId(orderBlock), orderBlock.direction, retest.candleIndex, code, debug));
      }
      return { confirmedIndex: null };
    }

    const confirmationAtr = atr[confirmationIndex] ?? atr[displacementIndex] ?? 0;
    const confirmation = candles[confirmationIndex];
    const entry = confirmation.close;
    const retestSlice = candles.slice(retest.candleIndex, confirmationIndex + 1);
    const retestExtreme = orderBlock.direction === "BUY"
      ? Math.min(...retestSlice.map((candle) => candle.low))
      : Math.max(...retestSlice.map((candle) => candle.high));
    const stopLoss = orderBlock.direction === "BUY"
      ? Math.min(orderBlock.bottom, retestExtreme) - confirmationAtr * CONFIG.slAtrBuffer
      : Math.max(orderBlock.top, retestExtreme) + confirmationAtr * CONFIG.slAtrBuffer;
    const risk = orderBlock.direction === "BUY" ? entry - stopLoss : stopLoss - entry;
    if (!(risk > 0) || risk > confirmationAtr * CONFIG.maxSlAtrMultiple) {
      addRejection(setupId(orderBlock), "INVALID_STOP_LOSS", orderBlock.direction, confirmationIndex, "REJECTED");
      return { confirmedIndex: null };
    }

    const target = findTarget(candles, confirmationIndex, orderBlock.direction, entry, risk);
    const reward = orderBlock.direction === "BUY" ? target.price - entry : entry - target.price;
    if (!Number.isFinite(target.price) || !(reward > 0)) {
      addRejection(setupId(orderBlock), "INVALID_TAKE_PROFIT", orderBlock.direction, confirmationIndex, "REJECTED");
      return { confirmedIndex: null };
    }
    const rr = reward / risk;
    if (!Number.isFinite(rr) || rr < CONFIG.minRR) {
      addRejection(setupId(orderBlock), "RR_BELOW_MINIMUM", orderBlock.direction, confirmationIndex, "REJECTED");
      return { confirmedIndex: null };
    }

    const local = zonedDateParts(confirmation.timestamp, SESSION_TIMEZONE);
    const sessionName = sessionNameAt(confirmation.timestamp);
    const sessionKey = `${local.date}:${sessionName}`;
    if ((sessionSignalCounts.get(sessionKey) ?? 0) >= CONFIG.maxSignalsPerSession) {
      addRejection(setupId(orderBlock), "MAX_SESSION_SIGNALS_REACHED", orderBlock.direction, confirmationIndex, "REJECTED");
      return { confirmedIndex: null };
    }
    if ((daySignalCounts.get(local.date) ?? 0) >= CONFIG.maxSignalsPerDay) {
      addRejection(setupId(orderBlock), "MAX_DAILY_SIGNALS_REACHED", orderBlock.direction, confirmationIndex, "REJECTED");
      return { confirmedIndex: null };
    }

    confirmationCandlesFound++;
    const warnings = buildWarnings(orderBlock, retest, target.fixed);
    const scoreParts = scoreSetup(candles, orderBlock, retest, confirmationIndex, rr);
    const bonus = (CONFIG.allowFvgBonus && orderBlock.hasFvg ? 5 : 0) + (CONFIG.allowLiquiditySweepBonus && orderBlock.hasLiquiditySweep ? 5 : 0);
    const score = Math.min(100, Object.values(scoreParts).reduce((sum, value) => sum + value, 0) + bonus);
    if (score < CONFIG.minSignalScore) {
      addRejection(setupId(orderBlock), "SIGNAL_SCORE_TOO_LOW", orderBlock.direction, confirmationIndex, "REJECTED");
      return { confirmedIndex: null };
    }

    const signal = buildSignal({
      input,
      candles,
      orderBlock,
      retest,
      confirmationIndex,
      entry,
      stopLoss,
      target: target.price,
      risk,
      reward,
      rr,
      score,
      scoreParts,
      warnings,
      fixedTarget: target.fixed,
      sessionName,
      atr: confirmationAtr,
    });
    signals.push(signal);
    sessionSignalCounts.set(sessionKey, (sessionSignalCounts.get(sessionKey) ?? 0) + 1);
    daySignalCounts.set(local.date, (daySignalCounts.get(local.date) ?? 0) + 1);
    candidateDebug.push(makeDebug(setupId(orderBlock), orderBlock.direction, "CONFIRMED", "CONFIRMED_SIGNAL", 0, "CONFIRMED_SIGNAL", score, rr));
    return { confirmedIndex: confirmationIndex };
  }

  function addRejection(setupIdValue: string, code: SignalRejectionCode, direction: Direction, index: number, stage: Stage): void {
    increment(rejectionCounts, code);
    const debug = makeDebug(setupIdValue, direction, "REJECTED", code, 0, stage);
    candidateDebug.push(debug);
    rejectedSetups.push(toRejected(setupIdValue, direction, index, code, debug));
  }

  const generationTimeMs = performance.now() - started;
  const topRejectionReasons = rejectionRows(rejectionCounts);
  const audit = makeAudit({
    candles: candles.length,
    signals,
    rejectedSetups,
    pendingCandidates,
    generationTimeMs,
    structureBreaksFound,
    orderBlocksCreated,
    validOrderBlocks,
    retestsFound,
    confirmationCandlesFound,
    expiredSetups,
    topRejectionReasons,
    candidateDebug,
  });

  const result: EntryEngineResult = {
    signals,
    activeSignals: signals,
    signalMap: new Map(signals.map((signal) => [signal.id, signal])),
    pendingCandidates,
    candidateDebug,
    rejectedSetups,
    noTrade: signals.length ? null : {
      status: "NO_TRADE",
      checkedSetups: validOrderBlocks,
      rejectionReasons: topRejectionReasons.map((row) => row.reason),
      message: pendingCandidates.length ? "Order block retest setup is still forming." : "No confirmed order block retest signal found.",
      nearestPossibleSetup: pendingCandidates.at(-1)?.setupId ?? null,
      requiredForSignal: ["Structure-breaking displacement", "Valid order block", "Retest into OB zone", "Closed confirmation candle", "Minimum 1.5R"],
      timestamp: candles.at(-1)?.timestamp ?? null,
    },
    audit,
  };
  if (resultCache.size >= 50) resultCache.delete(resultCache.keys().next().value ?? "");
  resultCache.set(key, result);
  return result;
}

function detectDisplacement(candles: Candle[], index: number, atr: number): Displacement | null {
  const candle = candles[index];
  const range = candle.high - candle.low;
  if (range <= 0 || range < atr * CONFIG.minDisplacementAtr) return null;
  const bodyRatio = Math.abs(candle.close - candle.open) / range;
  if (bodyRatio < CONFIG.displacementBodyRatio) return null;
  const closePosition = (candle.close - candle.low) / range;
  const direction: Direction | null = candle.close > candle.open && closePosition >= CONFIG.confirmationClosePosition
    ? "BUY"
    : candle.close < candle.open && closePosition <= 1 - CONFIG.confirmationClosePosition
      ? "SELL"
      : null;
  if (!direction) return null;
  const structureLevel = recentStructureLevel(candles, index, direction);
  if (CONFIG.requireStructureBreak && structureLevel === null) return null;
  if (structureLevel !== null) {
    const broke = direction === "BUY" ? candle.close > structureLevel : candle.close < structureLevel;
    if (!broke) return null;
  }
  return { direction, candleIndex: index, bodyRatio, rangeAtrMultiple: range / atr, structureLevel: structureLevel ?? candle.close };
}

function recentStructureLevel(candles: Candle[], index: number, direction: Direction): number | null {
  const candidates: number[] = [];
  const start = Math.max(CONFIG.swingLookback, index - 40);
  const end = index - CONFIG.swingLookback;
  for (let cursor = start; cursor <= end; cursor++) {
    if (direction === "BUY" && detectSwingHigh(candles, cursor, CONFIG.swingLookback)) candidates.push(candles[cursor].high);
    if (direction === "SELL" && detectSwingLow(candles, cursor, CONFIG.swingLookback)) candidates.push(candles[cursor].low);
  }
  if (candidates.length) return direction === "BUY" ? Math.max(...candidates) : Math.min(...candidates);
  const fallback = candles.slice(Math.max(0, index - 20), index);
  if (fallback.length < CONFIG.swingLookback) return null;
  return direction === "BUY" ? Math.max(...fallback.map((candle) => candle.high)) : Math.min(...fallback.map((candle) => candle.low));
}

function createOrderBlock(candles: Candle[], atr: Array<number | null>, displacement: Displacement): OrderBlock | null {
  const start = Math.max(0, displacement.candleIndex - 8);
  for (let index = displacement.candleIndex - 1; index >= start; index--) {
    const candle = candles[index];
    const opposite = displacement.direction === "BUY" ? candle.close < candle.open : candle.close > candle.open;
    if (!opposite) continue;
    const referenceAtr = atr[displacement.candleIndex] ?? atr[index];
    if (!referenceAtr) return null;
    const top = displacement.direction === "BUY" ? candle.open : candle.high;
    const bottom = displacement.direction === "BUY" ? candle.low : candle.open;
    const size = top - bottom;
    if (!(size > 0)) return null;
    return {
      type: displacement.direction === "BUY" ? "BULLISH_OB" : "BEARISH_OB",
      direction: displacement.direction,
      createdAt: candle.timestamp,
      candleIndex: index,
      displacementIndex: displacement.candleIndex,
      top,
      bottom,
      midpoint: (top + bottom) / 2,
      sizeAtr: size / referenceAtr,
      structureLevel: displacement.structureLevel,
      displacementBodyRatio: displacement.bodyRatio,
      displacementRangeAtr: displacement.rangeAtrMultiple,
      hasFvg: hasFvgNearOrderBlock(candles, displacement.candleIndex, displacement.direction, top, bottom),
      hasLiquiditySweep: hasLiquiditySweepBeforeDisplacement(candles, displacement.candleIndex, displacement.direction),
    };
  }
  return null;
}

function hasFvgNearOrderBlock(candles: Candle[], displacementIndex: number, direction: Direction, top: number, bottom: number): boolean {
  if (displacementIndex <= 0 || displacementIndex + 1 >= candles.length) return false;
  if (direction === "BUY") {
    const low = candles[displacementIndex + 1].low;
    const high = candles[displacementIndex - 1].high;
    return high < low && Math.abs(high - top) <= Math.max(top - bottom, Number.EPSILON) * 3;
  }
  const low = candles[displacementIndex - 1].low;
  const high = candles[displacementIndex + 1].high;
  return high < low && Math.abs(low - bottom) <= Math.max(top - bottom, Number.EPSILON) * 3;
}

function hasLiquiditySweepBeforeDisplacement(candles: Candle[], displacementIndex: number, direction: Direction): boolean {
  const window = candles.slice(Math.max(0, displacementIndex - 8), displacementIndex);
  if (window.length < 3) return false;
  const prior = candles.slice(Math.max(0, displacementIndex - 20), Math.max(0, displacementIndex - 8));
  if (prior.length < 3) return false;
  if (direction === "BUY") {
    const priorLow = Math.min(...prior.map((candle) => candle.low));
    return window.some((candle) => candle.low < priorLow && candle.close > priorLow);
  }
  const priorHigh = Math.max(...prior.map((candle) => candle.high));
  return window.some((candle) => candle.high > priorHigh && candle.close < priorHigh);
}

function touchesOrderBlock(candle: Candle, orderBlock: OrderBlock, atr: number): boolean {
  const tolerance = atr * CONFIG.retestToleranceAtr;
  return candle.low <= orderBlock.top + tolerance && candle.high >= orderBlock.bottom - tolerance;
}

function orderBlockInvalidated(candle: Candle, orderBlock: OrderBlock, atr: number): boolean {
  const tolerance = atr * CONFIG.retestToleranceAtr;
  return orderBlock.direction === "BUY"
    ? candle.close < orderBlock.bottom - tolerance
    : candle.close > orderBlock.top + tolerance;
}

function retestDepth(candle: Candle, orderBlock: OrderBlock): number {
  const size = Math.max(orderBlock.top - orderBlock.bottom, Number.EPSILON);
  if (orderBlock.direction === "BUY") {
    const touched = Math.max(orderBlock.bottom, Math.min(candle.low, orderBlock.top));
    return Math.round(((orderBlock.top - touched) / size) * 1000) / 10;
  }
  const touched = Math.max(orderBlock.bottom, Math.min(candle.high, orderBlock.top));
  return Math.round(((touched - orderBlock.bottom) / size) * 1000) / 10;
}

function isConfirmation(candle: Candle, atr: number, direction: Direction): boolean {
  const range = candle.high - candle.low;
  if (range <= 0 || range < atr * CONFIG.minConfirmationRangeAtr) return false;
  const bodyRatio = Math.abs(candle.close - candle.open) / range;
  const closePosition = (candle.close - candle.low) / range;
  return bodyRatio >= CONFIG.confirmationBodyRatio && (direction === "BUY"
    ? candle.close > candle.open && closePosition >= CONFIG.confirmationClosePosition
    : candle.close < candle.open && closePosition <= 1 - CONFIG.confirmationClosePosition);
}

function isDirectionalCandle(candle: Candle, direction: Direction): boolean {
  return direction === "BUY" ? candle.close > candle.open : candle.close < candle.open;
}

function findTarget(candles: Candle[], index: number, direction: Direction, entry: number, risk: number): { price: number; fixed: boolean } {
  const candidates: number[] = [];
  for (let cursor = Math.max(CONFIG.swingLookback, index - 60); cursor <= index - CONFIG.swingLookback; cursor++) {
    if (direction === "BUY" && detectSwingHigh(candles, cursor, CONFIG.swingLookback) && candles[cursor].high > entry) candidates.push(candles[cursor].high);
    if (direction === "SELL" && detectSwingLow(candles, cursor, CONFIG.swingLookback) && candles[cursor].low < entry) candidates.push(candles[cursor].low);
  }
  if (candidates.length) return { price: direction === "BUY" ? Math.min(...candidates) : Math.max(...candidates), fixed: false };
  const minimum = risk * CONFIG.minRR;
  return { price: direction === "BUY" ? entry + minimum : entry - minimum, fixed: true };
}

function scoreSetup(candles: Candle[], orderBlock: OrderBlock, retest: Retest, confirmationIndex: number, rr: number): ScoreParts {
  const confirmation = candles[confirmationIndex];
  const range = confirmation.high - confirmation.low;
  const bodyRatio = range > 0 ? Math.abs(confirmation.close - confirmation.open) / range : 0;
  const closePosition = range > 0 ? (confirmation.close - confirmation.low) / range : 0.5;
  const directionalClose = orderBlock.direction === "BUY" ? closePosition : 1 - closePosition;
  return {
    structureBreakQuality: Math.min(20, 14 + Math.round(Math.min(6, Math.abs(confirmation.close - orderBlock.structureLevel) / Math.max(orderBlock.top - orderBlock.bottom, Number.EPSILON)))),
    displacementQuality: Math.min(20, Math.round(10 + orderBlock.displacementBodyRatio * 5 + Math.min(5, orderBlock.displacementRangeAtr * 2))),
    orderBlockQuality: Math.min(20, orderBlock.sizeAtr <= 0.8 ? 20 : orderBlock.sizeAtr <= 1.1 ? 17 : 14),
    retestQuality: Math.min(15, Math.round(10 + Math.max(0, 50 - retest.retestDepthPercent) / 10)),
    confirmationQuality: Math.min(15, Math.round(6 + bodyRatio * 5 + directionalClose * 4)),
    rrQuality: Math.min(10, Math.round(7 + Math.min(3, (rr - CONFIG.minRR) * 2))),
  };
}

function buildWarnings(orderBlock: OrderBlock, retest: Retest, fixedTarget: boolean): string[] {
  const warnings = new Set<string>();
  if (retest.candleIndex - orderBlock.candleIndex > CONFIG.orderBlockMaxAgeCandles * 0.65) warnings.add("ORDER_BLOCK_OLD");
  if (retest.retestDepthPercent >= 70) warnings.add("ORDER_BLOCK_DEEP_RETEST");
  if (fixedTarget) warnings.add("TARGET_USING_FIXED_RR");
  if (!orderBlock.hasFvg) warnings.add("NO_FVG_CONFLUENCE");
  if (!orderBlock.hasLiquiditySweep) warnings.add("NO_LIQUIDITY_SWEEP_CONFLUENCE");
  return [...warnings];
}

function buildSignal(args: {
  input: V2GoldmineInput;
  candles: Candle[];
  orderBlock: OrderBlock;
  retest: Retest;
  confirmationIndex: number;
  entry: number;
  stopLoss: number;
  target: number;
  risk: number;
  reward: number;
  rr: number;
  score: number;
  scoreParts: ScoreParts;
  warnings: string[];
  fixedTarget: boolean;
  sessionName: string;
  atr: number;
}): TradeSignal {
  const confirmation = args.candles[args.confirmationIndex];
  const orderBlockCandle = args.candles[args.orderBlock.candleIndex];
  const displacement = args.candles[args.orderBlock.displacementIndex];
  const range = confirmation.high - confirmation.low;
  const bodyRatio = range > 0 ? Math.abs(confirmation.close - confirmation.open) / range : 0;
  const closePosition = range > 0 ? (confirmation.close - confirmation.low) / range : 0;
  const scoreBreakdown: SignalScoreBreakdown = {
    phase4Setup: args.scoreParts.structureBreakQuality + args.scoreParts.displacementQuality,
    contextAlignment: args.scoreParts.orderBlockQuality,
    confirmationCandle: args.scoreParts.confirmationQuality,
    stopLossQuality: args.scoreParts.retestQuality,
    targetQuality: args.scoreParts.rrQuality,
    sessionQuality: 0,
    volatilityQuality: 0,
    antiReversal: 0,
  };
  return {
    id: `${ORDER_BLOCK_RETEST_STRATEGY_ID}:${args.input.symbol}:${confirmation.timestamp}:${args.orderBlock.direction}`,
    engine: ACTIVE_SIGNAL_ENGINE,
    strategyId: ORDER_BLOCK_RETEST_STRATEGY_ID,
    v2Direction: args.orderBlock.direction,
    type: args.orderBlock.direction === "BUY" ? "CONFIRMED_BUY" : "CONFIRMED_SELL",
    direction: args.orderBlock.direction === "BUY" ? "BULLISH" : "BEARISH",
    status: "CONFIRMED",
    sourceSetupId: setupId(args.orderBlock),
    setupType: "TREND_CONTINUATION",
    strategyModel: ORDER_BLOCK_RETEST_STRATEGY_LABEL,
    mode: "V2_DEFAULT",
    timestamp: confirmation.timestamp,
    candleIndex: args.confirmationIndex,
    confirmedAtIndex: args.confirmationIndex,
    timeframe: args.input.timeframe,
    session: toTradingSession(args.sessionName),
    entryPrice: round(args.entry),
    stopLoss: round(args.stopLoss),
    takeProfit: round(args.target),
    takeProfit2: null,
    takeProfit3: null,
    riskPoints: round(args.risk),
    rewardPoints: round(args.reward),
    rr: round(args.rr, 3),
    score: args.score,
    confidence: confidenceFor(args.score),
    positionSizeSuggestion: round((args.input.settings?.maxRiskAmount ?? 100) / args.risk, 4),
    maxRiskAmount: args.input.settings?.maxRiskAmount ?? 100,
    invalidationLevel: round(args.stopLoss),
    reasons: [
      `${args.orderBlock.direction.toLowerCase()} displacement broke structure at ${args.orderBlock.structureLevel.toFixed(2)}.`,
      `${args.orderBlock.type} was retested and held.`,
      "A closed confirmation candle accepted the order-block retest.",
    ],
    warnings: args.warnings,
    rejectionReasons: [],
    relatedMarkers: [],
    noRepaintProof: {
      status: "PASS",
      signalIndex: args.confirmationIndex,
      latestAllowedCandleIndex: args.confirmationIndex,
      usedMarkerIndexes: [args.orderBlock.candleIndex, args.orderBlock.displacementIndex, args.retest.candleIndex, args.confirmationIndex],
      usedContextCloseTimes: [],
      usedSetupId: setupId(args.orderBlock),
      passed: true,
      lastAvailableIndex: args.confirmationIndex,
      maxEvidenceIndex: args.confirmationIndex,
      message: "Order block retest signal uses only closed candles through confirmation; entry, SL, TP, and RR are immutable.",
    },
    stopLossDetail: {
      price: round(args.stopLoss),
      source: "ORDER_BLOCK_RETEST_ATR_BUFFER",
      buffer: round(args.atr * CONFIG.slAtrBuffer),
      riskPoints: round(args.risk),
      reason: "Stop is beyond the order-block edge or retest extreme with ATR buffer.",
    },
    takeProfitDetail: {
      tp1: round(args.target),
      tp2: null,
      tp3: null,
      source: args.fixedTarget ? "FIXED_1_5R_FALLBACK" : "RECENT_STRUCTURE_LIQUIDITY",
      rewardPoints: round(args.reward),
      reason: args.fixedTarget ? "No qualifying swing liquidity target was available; fixed minimum-RR target used." : "Nearest recent swing liquidity target.",
    },
    scoreBreakdown,
    orderBlockRetest: {
      stage: "CONFIRMED_SIGNAL",
      signalTime: confirmation.timestamp,
      orderBlock: {
        type: args.orderBlock.type,
        createdAt: orderBlockCandle.timestamp,
        candleIndex: args.orderBlock.candleIndex,
        top: args.orderBlock.top,
        bottom: args.orderBlock.bottom,
        midpoint: args.orderBlock.midpoint,
        sizeAtr: args.orderBlock.sizeAtr,
        ageCandles: args.confirmationIndex - args.orderBlock.candleIndex,
      },
      displacement: {
        candleTime: displacement.timestamp,
        candleIndex: args.orderBlock.displacementIndex,
        bodyRatio: args.orderBlock.displacementBodyRatio,
        rangeAtrMultiple: args.orderBlock.displacementRangeAtr,
        brokeStructureLevel: args.orderBlock.structureLevel,
      },
      retest: {
        retestedAt: args.candles[args.retest.candleIndex].timestamp,
        candleIndex: args.retest.candleIndex,
        retestPrice: args.retest.retestPrice,
        retestDepthPercent: args.retest.retestDepthPercent,
      },
      confirmation: {
        candleTime: confirmation.timestamp,
        open: confirmation.open,
        high: confirmation.high,
        low: confirmation.low,
        close: confirmation.close,
        bodyRatio,
        closePosition,
        rangeAtrMultiple: range / args.atr,
      },
      confluence: {
        hasFvg: args.orderBlock.hasFvg,
        hasLiquiditySweep: args.orderBlock.hasLiquiditySweep,
      },
    },
    immutable: true,
  };
}

function makeDebug(
  setupIdValue: string,
  direction: Direction,
  status: SignalCandidateDebug["confirmationStatus"],
  reason: string,
  remaining: number,
  stage: Stage,
  score: number | null = null,
  rr: number | null = null,
): SignalCandidateDebug {
  return {
    setupId: setupIdValue,
    engine: ACTIVE_SIGNAL_ENGINE,
    strategyId: ORDER_BLOCK_RETEST_STRATEGY_ID,
    setupScore: 0,
    requiredSetupScore: 0,
    finalSignalScore: score,
    requiredSignalScore: CONFIG.minSignalScore,
    signalScore: score,
    rr,
    requiredRR: CONFIG.minRR,
    directionBias: direction === "BUY" ? "BULLISH" : "BEARISH",
    confirmationStatus: status,
    confirmationWindowRemaining: remaining,
    rejectionReason: reason,
    nextRequiredAction: stage === "WAITING_RETEST"
      ? "Wait for price to return to the order-block zone."
      : stage === "WAITING_CONFIRMATION"
        ? "Wait for a closed confirmation candle from the order block."
        : stage === "CONFIRMED_SIGNAL"
          ? "Use immutable trade levels."
          : "Wait for a new displacement and order block.",
    failedStage: stage,
  };
}

function toRejected(setupIdValue: string, direction: Direction, index: number, code: SignalRejectionCode, debug: SignalCandidateDebug): RejectedSetup {
  return {
    setupId: setupIdValue,
    setupType: "TREND_CONTINUATION",
    setupState: code === "ORDER_BLOCK_EXPIRED" || code === "RETEST_EXPIRED" ? "EXPIRED" : "INVALIDATED",
    direction: direction === "BUY" ? "BULLISH" : "BEARISH",
    triggerIndex: index,
    rejectionReasons: [code],
    rejectionReasonCodes: [code],
    debug,
  };
}

function makeAudit(args: {
  candles: number;
  signals: TradeSignal[];
  rejectedSetups: RejectedSetup[];
  pendingCandidates: SignalCandidateDebug[];
  generationTimeMs: number;
  structureBreaksFound: number;
  orderBlocksCreated: number;
  validOrderBlocks: number;
  retestsFound: number;
  confirmationCandlesFound: number;
  expiredSetups: number;
  topRejectionReasons: Array<{ reason: string; count: number; percentage: number }>;
  candidateDebug: SignalCandidateDebug[];
}): EntryEngineResult["audit"] {
  return {
    activeEngine: ACTIVE_SIGNAL_ENGINE,
    strategyId: ORDER_BLOCK_RETEST_STRATEGY_ID,
    activeMode: "V2_DEFAULT",
    minimumScoreRequired: CONFIG.minSignalScore,
    minimumSetupScoreRequired: 0,
    minimumSignalScoreRequired: CONFIG.minSignalScore,
    minimumRrRequired: CONFIG.minRR,
    totalCandlesScanned: args.candles,
    totalMarkersGenerated: 0,
    totalContextsGenerated: 0,
    totalPhase4Setups: 0,
    watchCount: args.pendingCandidates.length,
    setupCount: args.validOrderBlocks,
    invalidatedCount: args.rejectedSetups.length,
    expiredCount: args.expiredSetups,
    totalSetupsScanned: args.orderBlocksCreated,
    triggerSetupsFound: args.retestsFound,
    pendingConfirmationCount: args.pendingCandidates.length,
    expiredConfirmationCount: args.expiredSetups,
    invalidatedCandidateCount: args.rejectedSetups.length,
    confirmedBuyCount: args.signals.filter((signal) => signal.direction === "BULLISH").length,
    confirmedSellCount: args.signals.filter((signal) => signal.direction === "BEARISH").length,
    rapidBuyCount: 0,
    rapidSellCount: 0,
    rapidSignalCount: 0,
    rejectedSetupCount: args.rejectedSetups.length,
    lastRejectionReason: args.rejectedSetups.at(-1)?.rejectionReasons[0] ?? null,
    lastConfirmedSignal: args.signals.at(-1)?.id ?? null,
    topRejectionReasons: args.topRejectionReasons.map(({ reason, count }) => ({ reason, count })),
    lastFiveTriggerSetups: args.candidateDebug.slice(-5).map((item) => item.setupId),
    lastFiveConfirmedSignals: args.signals.slice(-5).map((signal) => signal.id),
    noSignalMessage: args.signals.length ? null : "No confirmed order block retest signal.",
    noRepaintWarnings: [],
    rrCalculation: args.signals.at(-1) ? `${args.signals.at(-1)!.rr.toFixed(2)}R` : null,
    stopLossSource: args.signals.at(-1)?.stopLossDetail.source ?? null,
    takeProfitSource: args.signals.at(-1)?.takeProfitDetail.source ?? null,
    scoreBreakdown: args.signals.at(-1)?.scoreBreakdown ?? null,
    lastCandidateDebug: args.candidateDebug.at(-1) ?? null,
    noRepaintValidation: "PASS",
    calculationTimeMs: args.generationTimeMs,
    generationTimeMs: args.generationTimeMs,
    cacheStatus: "miss",
    v2OrderBlockRetest: {
      activeEngineLabel: ORDER_BLOCK_RETEST_STRATEGY_LABEL,
      strategyId: ORDER_BLOCK_RETEST_STRATEGY_ID,
      candlesScanned: args.candles,
      structureBreaksFound: args.structureBreaksFound,
      orderBlocksCreated: args.orderBlocksCreated,
      validOrderBlocks: args.validOrderBlocks,
      retestsFound: args.retestsFound,
      confirmationCandlesFound: args.confirmationCandlesFound,
      confirmedSignals: args.signals.length,
      rejectedSignals: args.rejectedSetups.length,
      expiredSetups: args.expiredSetups,
      generationTimeMs: args.generationTimeMs,
      topRejectionReasons: args.topRejectionReasons,
    },
  };
}

function setupId(orderBlock: OrderBlock): string {
  return `order-block:${orderBlock.createdAt}:${orderBlock.direction}:${orderBlock.displacementIndex}`;
}

function sessionNameAt(timestamp: number): string {
  const local = zonedDateParts(timestamp, SESSION_TIMEZONE);
  const minute = local.hour * 60 + local.minute;
  if (minute >= 8 * 60 && minute < 11 * 60) return "OVERLAP";
  if (minute >= 3 * 60 && minute < 6 * 60) return "LONDON";
  if (minute >= 8 * 60 + 30 && minute < 11 * 60 + 30) return "NY_AM";
  return "OFF_SESSION";
}

function toTradingSession(session: string): TradingSession {
  if (session === "LONDON") return "LONDON";
  if (session === "OVERLAP") return "LONDON_NEW_YORK_OVERLAP";
  if (session === "NY_AM") return "NEW_YORK";
  return "DEAD_ZONE";
}

function rejectionRows(counts: Map<string, number>) {
  const total = [...counts.values()].reduce((sum, count) => sum + count, 0);
  return [...counts.entries()]
    .map(([reason, count]) => ({ reason, count, percentage: total ? Math.round((count / total) * 1000) / 10 : 0 }))
    .sort((a, b) => b.count - a.count || a.reason.localeCompare(b.reason));
}

function increment(map: Map<string, number>, key: string): void {
  map.set(key, (map.get(key) ?? 0) + 1);
}

function cloneResult(result: EntryEngineResult, cacheStatus: "hit" | "miss"): EntryEngineResult {
  return { ...result, signalMap: new Map(result.signalMap), audit: { ...result.audit, cacheStatus } };
}

function confidenceFor(score: number): TradeSignal["confidence"] {
  return score >= 90 ? "PREMIUM" : score >= 78 ? "STRONG" : score >= 65 ? "MODERATE" : "LOW_CONFIRMED";
}

function round(value: number, digits = 5): number {
  const factor = 10 ** digits;
  return Math.round((value + Number.EPSILON) * factor) / factor;
}
