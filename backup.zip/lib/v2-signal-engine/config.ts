export const ACTIVE_SIGNAL_ENGINE = "V2_GOLDMINE" as const;
export const ACTIVE_SIGNAL_ENGINE_LABEL = "V2 Goldmine Strategy Engine";
export const GOLDMINE_STRATEGY_ID = "GOLDMINE_ASIAN_SWEEP_REVERSAL" as const;
export const GOLDMINE_STRATEGY_LABEL = "Goldmine Asian Sweep Reversal";
export const BREAKOUT_STRATEGY_ID = "ASIAN_RANGE_BREAKOUT_RETEST" as const;
export const BREAKOUT_STRATEGY_LABEL = "Asian Range Breakout Retest";
export const ICT_SILVER_BULLET_STRATEGY_ID = "ICT_SILVER_BULLET" as const;
export const ICT_SILVER_BULLET_STRATEGY_LABEL = "ICT Silver Bullet";
export const VWAP_EMA_STRATEGY_ID = "VWAP_EMA_REGIME_PULLBACK" as const;
export const VWAP_EMA_STRATEGY_LABEL = "VWAP EMA Regime Pullback";
export const EMA_TREND_PULLBACK_STRATEGY_ID = "EMA_TREND_PULLBACK" as const;
export const EMA_TREND_PULLBACK_STRATEGY_LABEL = "EMA Trend Pullback";
export const LIQUIDITY_SWEEP_REVERSAL_PRO_STRATEGY_ID = "LIQUIDITY_SWEEP_REVERSAL_PRO" as const;
export const LIQUIDITY_SWEEP_REVERSAL_PRO_STRATEGY_LABEL = "Liquidity Sweep Reversal Pro";
export const ORDER_BLOCK_RETEST_STRATEGY_ID = "ORDER_BLOCK_RETEST_CONFIRMATION" as const;
export const ORDER_BLOCK_RETEST_STRATEGY_LABEL = "Order Block Retest Confirmation";
export const FVG_CONTINUATION_ENTRY_STRATEGY_ID = "FVG_CONTINUATION_ENTRY" as const;
export const FVG_CONTINUATION_ENTRY_STRATEGY_LABEL = "FVG Continuation Entry";

export const ICT_SILVER_BULLET_CONFIG = {
  strategyId: ICT_SILVER_BULLET_STRATEGY_ID,
  enabled: true,
  defaultTimeframe: "1m",
  allowedTimeframes: ["1m", "5m"],
  timezone: "America/New_York",
  killzones: [
    { name: "LONDON_SB", start: "03:00", end: "04:00" },
    { name: "NY_AM_SB", start: "10:00", end: "11:00" },
    { name: "NY_PM_SB", start: "14:00", end: "15:00" },
  ],
  atrPeriod: 14,
  liquidityLookback: 30,
  swingLookback: 5,
  equalHighLowToleranceAtr: 0.12,
  lookbackCandlesForLiquidity: 30,
  minSweepBufferAtr: 0.05,
  maxSweepDistanceAtr: 1.25,
  requireReclaimClose: true,
  allowNextCandleReclaim: true,
  displacementBodyRatio: 0.55,
  displacementClosePosition: 0.65,
  minDisplacementRangeAtr: 0.35,
  minDisplacementAtr: 0.35,
  requireMSS: true,
  allowChoChInsteadOfMss: true,
  fvgMinSizeAtr: 0.08,
  maxCandlesToCreateFvgAfterSweep: 5,
  maxCandlesToReturnToFvg: 10,
  maxCandlesToConfirmAfterFvgTap: 4,
  fvgEntryZone: "MIDPOINT_OR_BETTER",
  confirmationBodyRatio: 0.40,
  confirmationClosePosition: 0.60,
  minConfirmationRangeAtr: 0.20,
  minRR: 1.5,
  preferredRR: 2.0,
  minSignalScore: 65,
  slAtrBuffer: 0.20,
  maxSlAtrMultiple: 2.8,
  maxSignalsPerKillzone: 1,
  maxSignalsPerDay: 3,
} as const;

export const VWAP_EMA_REGIME_PULLBACK_CONFIG = {
  strategyId: VWAP_EMA_STRATEGY_ID,
  enabled: true,
  timeframe: "5m",
  emaFastPeriod: 20,
  emaMidPeriod: 50,
  emaRegimePeriod: 200,
  atrPeriod: 14,
  useSessionVWAP: true,
  sessionTimezone: "America/New_York",
  vwapSessionStart: "00:00",
  allowedSessions: [
    { name: "LONDON", start: "03:00", end: "06:00" },
    { name: "NY_AM", start: "08:30", end: "11:30" },
    { name: "OVERLAP", start: "08:00", end: "11:00" },
  ],
  maxDistanceFromVwapAtr: 2.5,
  minDistanceFromVwapAtr: 0.1,
  pullbackZoneAtrBuffer: 0.25,
  maxPullbackCandles: 8,
  confirmationBodyRatio: 0.45,
  confirmationClosePosition: 0.60,
  minConfirmationAtr: 0.25,
  minRR: 1.5,
  minSignalScore: 60,
  slAtrBuffer: 0.20,
  maxSlAtrMultiple: 2.5,
  maxSignalsPerSession: 2,
  maxSignalsPerDay: 5,
} as const;

export const EMA_TREND_PULLBACK_CONFIG = {
  strategyId: EMA_TREND_PULLBACK_STRATEGY_ID,
  enabled: true,
  defaultTimeframe: "5m",
  emaFastPeriod: 20,
  emaMidPeriod: 50,
  emaSlowPeriod: 200,
  atrPeriod: 14,
  allowedSessions: [
    { name: "LONDON", start: "03:00", end: "06:00", timezone: "America/New_York" },
    { name: "NY_AM", start: "08:30", end: "11:30", timezone: "America/New_York" },
    { name: "OVERLAP", start: "08:00", end: "11:00", timezone: "America/New_York" },
  ],
  requireSession: true,
  pullbackZoneAtrBuffer: 0.30,
  maxPullbackCandles: 8,
  minTrendStrengthAtr: 0.20,
  maxEmaDistanceAtr: 3.0,
  confirmationBodyRatio: 0.45,
  confirmationClosePosition: 0.60,
  minConfirmationRangeAtr: 0.25,
  minRR: 1.5,
  minSignalScore: 58,
  slAtrBuffer: 0.20,
  maxSlAtrMultiple: 2.5,
  maxSignalsPerSession: 2,
  maxSignalsPerDay: 5,
} as const;

export const LIQUIDITY_SWEEP_REVERSAL_PRO_CONFIG = {
  strategyId: LIQUIDITY_SWEEP_REVERSAL_PRO_STRATEGY_ID,
  enabled: true,
  defaultTimeframe: "5m",
  atrPeriod: 14,
  swingLookback: 5,
  liquidityLookback: 40,
  equalHighLowToleranceAtr: 0.12,
  minSweepBufferAtr: 0.05,
  maxSweepDistanceAtr: 1.2,
  requireCloseBackInside: true,
  allowNextCandleReclaim: true,
  confirmationWindow: 4,
  confirmationBodyRatio: 0.45,
  confirmationClosePosition: 0.60,
  minConfirmationRangeAtr: 0.25,
  requireMSS: false,
  allowMssBonus: true,
  allowFvgBonus: true,
  minRR: 1.5,
  minSignalScore: 60,
  slAtrBuffer: 0.20,
  maxSlAtrMultiple: 2.8,
  allowedSessions: [
    { name: "LONDON", start: "03:00", end: "06:00", timezone: "America/New_York" },
    { name: "NY_AM", start: "08:30", end: "11:30", timezone: "America/New_York" },
    { name: "OVERLAP", start: "08:00", end: "11:00", timezone: "America/New_York" },
  ],
  requireSession: false,
  sessionWarningOnly: true,
  maxSignalsPerDay: 6,
} as const;

export const ORDER_BLOCK_RETEST_CONFIG = {
  strategyId: ORDER_BLOCK_RETEST_STRATEGY_ID,
  enabled: true,
  defaultTimeframe: "5m",
  atrPeriod: 14,
  swingLookback: 5,
  displacementBodyRatio: 0.55,
  minDisplacementAtr: 0.40,
  orderBlockMaxAgeCandles: 80,
  orderBlockMinSizeAtr: 0.10,
  orderBlockMaxSizeAtr: 1.50,
  retestToleranceAtr: 0.15,
  maxRetestCandles: 40,
  confirmationBodyRatio: 0.45,
  confirmationClosePosition: 0.60,
  minConfirmationRangeAtr: 0.25,
  minRR: 1.5,
  minSignalScore: 62,
  slAtrBuffer: 0.20,
  maxSlAtrMultiple: 2.8,
  requireStructureBreak: true,
  allowFvgBonus: true,
  allowLiquiditySweepBonus: true,
  maxSignalsPerSession: 2,
  maxSignalsPerDay: 5,
} as const;

export const FVG_CONTINUATION_ENTRY_CONFIG = {
  strategyId: FVG_CONTINUATION_ENTRY_STRATEGY_ID,
  enabled: true,
  defaultTimeframe: "5m",
  allowedTimeframes: ["1m", "5m", "15m"],
  atrPeriod: 14,
  swingLookback: 5,
  structureLookback: 20,
  displacementBodyRatio: 0.55,
  displacementClosePosition: 0.65,
  minDisplacementRangeAtr: 0.40,
  requireStructureBreak: true,
  allowChoChInsteadOfBOS: true,
  fvgMinSizeAtr: 0.08,
  fvgMaxSizeAtr: 2.0,
  maxFvgAgeCandles: 40,
  fvgEntryZone: "MIDPOINT_OR_BETTER",
  retestToleranceAtr: 0.10,
  maxCandlesToReturnToFvg: 12,
  confirmationBodyRatio: 0.42,
  confirmationClosePosition: 0.60,
  minConfirmationRangeAtr: 0.25,
  confirmationWindow: 4,
  minRR: 1.5,
  preferredRR: 2.0,
  minSignalScore: 62,
  slAtrBuffer: 0.20,
  maxSlAtrMultiple: 2.8,
  allowedSessions: [
    { name: "LONDON", start: "03:00", end: "06:00", timezone: "America/New_York" },
    { name: "NY_AM", start: "08:30", end: "11:30", timezone: "America/New_York" },
    { name: "OVERLAP", start: "08:00", end: "11:00", timezone: "America/New_York" },
  ],
  requireSession: false,
  sessionWarningOnly: true,
  allowLiquiditySweepBonus: true,
  allowOrderBlockBonus: true,
  allowEmaTrendBonus: true,
  maxSignalsPerSession: 2,
  maxSignalsPerDay: 5,
} as const;

export type IctSilverBulletConfig = typeof ICT_SILVER_BULLET_CONFIG;
export type VwapEmaRegimePullbackConfig = typeof VWAP_EMA_REGIME_PULLBACK_CONFIG;
export type EmaTrendPullbackConfig = typeof EMA_TREND_PULLBACK_CONFIG;
export type LiquiditySweepReversalProConfig = typeof LIQUIDITY_SWEEP_REVERSAL_PRO_CONFIG;
export type OrderBlockRetestConfig = typeof ORDER_BLOCK_RETEST_CONFIG;
export type FvgContinuationEntryConfig = typeof FVG_CONTINUATION_ENTRY_CONFIG;

export const ASIAN_RANGE_CONFIG = {
  strictCompleteRangeRequired: false,
  allowPartialAsianRange: true,
  allowLargeAsianRange: true,
  largeRangeIsWarningOnly: true,
  incompleteRangeIsWarningOnly: true,
  minCoverageRatio: 0.35,
  fallbackLookbackHours: 6,
} as const;

export type AsianRangeConfig = typeof ASIAN_RANGE_CONFIG;

/**
 * Single unified config for the Asian Range Breakout Retest strategy.
 */
export const ASIAN_BREAKOUT_CONFIG = {
  minSignalScore: 60,
  minRR: 1.5,
  confirmationWindow: 6,

  requireAsianRange: true,
  requireBreakoutClose: true,
  requireRetest: true,
  requireMomentumBreakout: true,

  breakoutBodyMinRatio: 0.45,
  breakoutCloseBufferAtr: 0.05,
  retestToleranceAtr: 0.15,
  retestWindowCandles: 8,

  atrBufferMultiplier: 0.10,
  maxSignalsPerDay: 2,

  tradeLondon: true,
  tradeNewYork: true,
  allowOutsideSessionSignals: false,

  allowFixedRRFallback: true,
} as const;

export type AsianBreakoutConfig = typeof ASIAN_BREAKOUT_CONFIG;

/**
 * Single unified config for the Goldmine Asian Sweep Reversal strategy.
 * No modes — one practical rule set for all signal generation.
 */
export const GOLDMINE_CONFIG = {
  minSignalScore: 55,
  minRR: 1.5,
  confirmationWindow: 6,
  requireAsianRange: true,
  requireSweep: true,
  requireRejection: true,

  // MSS is preferred but not always required
  requireMSS: false,
  allowDisplacementInsteadOfMSS: true,

  // TP logic
  allowAsianMidpointAsTP1: true,
  allowAsianHighLowAsTP2: true,
  allowLiquidityTargetAsTP3: true,
  allowFixedRRFallback: true,

  // session
  tradeLondon: true,
  tradeNewYork: true,
  allowOutsideSessionSignals: false,

  // risk
  atrBufferMultiplier: 0.10,
  maxConfirmationCandles: 6,
  maxSignalsPerDay: 3,
} as const;

export type GoldmineConfig = typeof GOLDMINE_CONFIG;

export const UTC_SESSIONS = {
  asian: { startHour: 0, endHour: 7 },
  london: { startHour: 7, endHour: 11 },
  newYork: { startHour: 12, endHour: 16 },
} as const;
