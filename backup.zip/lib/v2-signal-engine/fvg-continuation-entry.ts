import type { Candle } from "../candles/types";
import type {
  EntryEngineResult,
  RejectedSetup,
  SignalCandidateDebug,
  SignalRejectionCode,
  SignalScoreBreakdown,
  TradeSignal,
} from "../entry-engine/types";
import type { TradingSession } from "../market-context/types";
import {
  ACTIVE_SIGNAL_ENGINE,
  FVG_CONTINUATION_ENTRY_CONFIG as CONFIG,
  FVG_CONTINUATION_ENTRY_STRATEGY_ID,
  FVG_CONTINUATION_ENTRY_STRATEGY_LABEL,
} from "./config";
import { calculateATR, calculateEMA, clockWindowAt, detectFVG, detectSwingHigh, detectSwingLow, zonedDateParts } from "./indicators";
import type { V2GoldmineInput } from "./types";

type Direction = "BUY" | "SELL";
type Stage =
  | "DISPLACEMENT_DETECTED"
  | "STRUCTURE_BREAK_CONFIRMED"
  | "FVG_CREATED"
  | "WAITING_FVG_RETEST"
  | "FVG_RETESTED"
  | "WAITING_CONFIRMATION"
  | "CONFIRMED_SIGNAL"
  | "REJECTED"
  | "EXPIRED";

type Displacement = {
  direction: Direction;
  candleIndex: number;
  bodyRatio: number;
  closePosition: number;
  rangeAtrMultiple: number;
  structureBreak: StructureBreak;
};

type StructureBreak = {
  type: "BOS" | "CHOCH";
  brokenLevel: number;
};

type FvgSetup = {
  direction: Direction;
  type: "BULLISH_FVG" | "BEARISH_FVG";
  createdAtIndex: number;
  displacementIndex: number;
  top: number;
  bottom: number;
  midpoint: number;
  size: number;
  sizeAtr: number;
  displacement: Displacement;
  hasLiquiditySweep: boolean;
  hasOrderBlock: boolean;
  emaTrendAligned: boolean;
};

type Retest = {
  candleIndex: number;
  retestPrice: number;
  touchedZone: "TOP" | "MIDPOINT" | "BOTTOM";
  retestDepthPercent: number;
};

type ScoreParts = {
  displacementQuality: number;
  structureBreakQuality: number;
  fvgQuality: number;
  retestQuality: number;
  confirmationQuality: number;
  rrQuality: number;
};

const resultCache = new Map<string, EntryEngineResult>();
const SESSION_TIMEZONE = "America/New_York";

export function clearFvgContinuationEntryCache(): void {
  resultCache.clear();
}

export function generateFvgContinuationEntrySignals(input: V2GoldmineInput): EntryEngineResult {
  const started = performance.now();
  const candles = input.candles.filter((candle) => candle.isClosed);
  const key = `${FVG_CONTINUATION_ENTRY_STRATEGY_ID}:${input.symbol}:${input.timeframe}:${candles.length}:${candles.at(-1)?.timestamp ?? 0}:${input.settings?.maxRiskAmount ?? 100}`;
  const cached = resultCache.get(key);
  if (cached) return cloneResult(cached, "hit");

  const atr = calculateATR(candles, CONFIG.atrPeriod);
  const ema20 = calculateEMA(candles, 20);
  const ema50 = calculateEMA(candles, 50);
  const ema200 = calculateEMA(candles, 200);
  const signals: TradeSignal[] = [];
  const pendingCandidates: SignalCandidateDebug[] = [];
  const candidateDebug: SignalCandidateDebug[] = [];
  const rejectedSetups: RejectedSetup[] = [];
  const rejectionCounts = new Map<string, number>();
  const sessionSignalCounts = new Map<string, number>();
  const daySignalCounts = new Map<string, number>();
  let displacementsFound = 0;
  let structureBreaksConfirmed = 0;
  let fvgsCreated = 0;
  let validFvgs = 0;
  let fvgRetestsFound = 0;
  let confirmationCandlesFound = 0;
  let expiredSetups = 0;

  if (candles.length < CONFIG.atrPeriod + CONFIG.swingLookback * 2 + 3) {
    increment(rejectionCounts, "INSUFFICIENT_CANDLES");
  }

  const firstIndex = Math.max(CONFIG.atrPeriod, CONFIG.swingLookback * 2 + 2);
  for (let index = firstIndex; index < candles.length; index++) {
    const currentAtr = atr[index];
    if (!currentAtr || !Number.isFinite(currentAtr)) {
      increment(rejectionCounts, "INSUFFICIENT_CANDLES");
      continue;
    }

    const displacement = detectDisplacement(candles, index, currentAtr);
    if (!displacement) continue;
    displacementsFound++;
    structureBreaksConfirmed++;

    const fvg = findFvgForDisplacement(displacement);
    if (!fvg) {
      const maxFvgIndex = Math.min(candles.length - 1, displacement.candleIndex + 1);
      if (candles.length - 1 < displacement.candleIndex + 1) {
        const debug = makeDebug(setupIdFromDisplacement(candles, displacement), displacement.direction, "PENDING_CONFIRMATION", "NO_VALID_FVG", 1, "STRUCTURE_BREAK_CONFIRMED");
        candidateDebug.push(debug);
        pendingCandidates.push(debug);
      } else {
        addRejection(setupIdFromDisplacement(candles, displacement), "NO_VALID_FVG", displacement.direction, maxFvgIndex, "REJECTED");
      }
      continue;
    }
    fvgsCreated++;
    validFvgs++;

    const evaluated = evaluateFvg(fvg);
    if (evaluated.confirmedIndex !== null) {
      index = Math.max(index, evaluated.confirmedIndex);
    }
  }

  if (displacementsFound === 0) {
    increment(rejectionCounts, "NO_DISPLACEMENT");
  }

  function findFvgForDisplacement(displacement: Displacement): FvgSetup | null {
    for (const fvgIndex of [displacement.candleIndex, displacement.candleIndex + 1]) {
      if (fvgIndex >= candles.length) continue;
      const detection = detectFVG(candles, fvgIndex);
      if (!detection) continue;
      if (displacement.direction === "BUY" && detection.type !== "BULLISH_FVG") continue;
      if (displacement.direction === "SELL" && detection.type !== "BEARISH_FVG") continue;
      const referenceAtr = atr[fvgIndex] ?? atr[displacement.candleIndex];
      if (!referenceAtr) continue;
      const sizeAtr = detection.size / referenceAtr;
      if (sizeAtr < CONFIG.fvgMinSizeAtr) {
        addRejection(setupIdFromDisplacement(candles, displacement), "FVG_TOO_SMALL", displacement.direction, fvgIndex, "REJECTED");
        return null;
      }
      if (sizeAtr > CONFIG.fvgMaxSizeAtr) {
        addRejection(setupIdFromDisplacement(candles, displacement), "FVG_TOO_LARGE", displacement.direction, fvgIndex, "REJECTED");
        return null;
      }
      return {
        direction: displacement.direction,
        type: detection.type,
        createdAtIndex: fvgIndex,
        displacementIndex: displacement.candleIndex,
        top: detection.top,
        bottom: detection.bottom,
        midpoint: detection.midpoint,
        size: detection.size,
        sizeAtr,
        displacement,
        hasLiquiditySweep: hasLiquiditySweepBeforeDisplacement(candles, displacement.candleIndex, displacement.direction),
        hasOrderBlock: hasOrderBlockNearFvg(candles, displacement.candleIndex, displacement.direction, detection.bottom, detection.top),
        emaTrendAligned: emaTrendAligned(ema20, ema50, ema200, fvgIndex, displacement.direction),
      };
    }
    return null;
  }

  function evaluateFvg(fvg: FvgSetup): { confirmedIndex: number | null } {
    const trueRetestDeadline = Math.min(fvg.createdAtIndex + CONFIG.maxCandlesToReturnToFvg, fvg.createdAtIndex + CONFIG.maxFvgAgeCandles);
    const maxRetestIndex = Math.min(candles.length - 1, trueRetestDeadline);
    let retest: Retest | null = null;

    for (let check = fvg.createdAtIndex + 1; check <= maxRetestIndex; check++) {
      const checkAtr = atr[check] ?? atr[fvg.createdAtIndex];
      if (!checkAtr) continue;
      if (fvgInvalidated(candles[check], fvg, checkAtr)) {
        const code: SignalRejectionCode = touchesFvg(candles[check], fvg, checkAtr) ? "FVG_INVALIDATED" : "FVG_ALREADY_FILLED";
        addRejection(setupId(fvg), code, fvg.direction, check, "REJECTED");
        return { confirmedIndex: null };
      }
      if (touchesFvg(candles[check], fvg, checkAtr)) {
        retest = makeRetest(candles[check], fvg, check);
        fvgRetestsFound++;
        break;
      }
    }

    if (!retest) {
      const waiting = candles.length - 1 < trueRetestDeadline;
      const debug = makeDebug(
        setupId(fvg),
        fvg.direction,
        waiting ? "PENDING_CONFIRMATION" : "EXPIRED_CONFIRMATION",
        "FVG_RETEST_EXPIRED",
        Math.max(0, trueRetestDeadline - (candles.length - 1)),
        waiting ? "WAITING_FVG_RETEST" : "EXPIRED",
      );
      candidateDebug.push(debug);
      if (waiting) {
        pendingCandidates.push(debug);
      } else {
        expiredSetups++;
        increment(rejectionCounts, "FVG_RETEST_EXPIRED");
        rejectedSetups.push(toRejected(setupId(fvg), fvg.direction, maxRetestIndex, "FVG_RETEST_EXPIRED", debug, "EXPIRED"));
      }
      return { confirmedIndex: null };
    }

    const confirmationLimit = Math.min(candles.length - 1, retest.candleIndex + CONFIG.confirmationWindow);
    let confirmationIndex = -1;
    let weakConfirmation = false;
    for (let check = retest.candleIndex + 1; check <= confirmationLimit; check++) {
      const checkAtr = atr[check] ?? atr[fvg.createdAtIndex];
      if (!checkAtr) continue;
      if (fvgInvalidated(candles[check], fvg, checkAtr)) {
        addRejection(setupId(fvg), "FVG_INVALIDATED", fvg.direction, check, "REJECTED");
        return { confirmedIndex: null };
      }
      if (isConfirmation(candles[check], checkAtr, fvg.direction, fvg)) {
        confirmationIndex = check;
        break;
      }
      if (isDirectionalCandle(candles[check], fvg.direction)) weakConfirmation = true;
    }

    if (confirmationIndex < 0) {
      const trueDeadline = retest.candleIndex + CONFIG.confirmationWindow;
      const waiting = candles.length - 1 < trueDeadline;
      const code: SignalRejectionCode = waiting ? "WEAK_CONFIRMATION_CANDLE" : weakConfirmation ? "WEAK_CONFIRMATION_CANDLE" : "CONFIRMATION_EXPIRED";
      const debug = makeDebug(
        setupId(fvg),
        fvg.direction,
        waiting ? "PENDING_CONFIRMATION" : "EXPIRED_CONFIRMATION",
        code,
        Math.max(0, trueDeadline - (candles.length - 1)),
        waiting ? "WAITING_CONFIRMATION" : "EXPIRED",
      );
      candidateDebug.push(debug);
      if (waiting) {
        pendingCandidates.push(debug);
      } else {
        expiredSetups++;
        increment(rejectionCounts, code);
        rejectedSetups.push(toRejected(setupId(fvg), fvg.direction, retest.candleIndex, code, debug, "EXPIRED"));
      }
      return { confirmedIndex: null };
    }

    confirmationCandlesFound++;
    const confirmationAtr = atr[confirmationIndex] ?? atr[fvg.createdAtIndex] ?? 0;
    const confirmation = candles[confirmationIndex];
    const entry = confirmation.close;
    const retestSlice = candles.slice(retest.candleIndex, confirmationIndex + 1);
    const retestExtreme = fvg.direction === "BUY"
      ? Math.min(...retestSlice.map((candle) => candle.low))
      : Math.max(...retestSlice.map((candle) => candle.high));
    const displacement = candles[fvg.displacementIndex];
    const stopLoss = fvg.direction === "BUY"
      ? Math.min(fvg.bottom, retestExtreme, displacement.low) - confirmationAtr * CONFIG.slAtrBuffer
      : Math.max(fvg.top, retestExtreme, displacement.high) + confirmationAtr * CONFIG.slAtrBuffer;
    const risk = fvg.direction === "BUY" ? entry - stopLoss : stopLoss - entry;
    if (!(risk > 0) || risk > confirmationAtr * CONFIG.maxSlAtrMultiple) {
      addRejection(setupId(fvg), "INVALID_STOP_LOSS", fvg.direction, confirmationIndex, "REJECTED");
      return { confirmedIndex: null };
    }

    const target = findTarget(candles, confirmationIndex, fvg.direction, entry, risk);
    const reward = fvg.direction === "BUY" ? target.price - entry : entry - target.price;
    if (!Number.isFinite(target.price) || !(reward > 0)) {
      addRejection(setupId(fvg), "INVALID_TAKE_PROFIT", fvg.direction, confirmationIndex, "REJECTED");
      return { confirmedIndex: null };
    }
    const rr = reward / risk;
    if (!Number.isFinite(rr) || rr < CONFIG.minRR) {
      addRejection(setupId(fvg), "RR_BELOW_MINIMUM", fvg.direction, confirmationIndex, "REJECTED");
      return { confirmedIndex: null };
    }

    const sessionName = sessionNameAt(confirmation.timestamp);
    const local = zonedDateParts(confirmation.timestamp, SESSION_TIMEZONE);
    const sessionKey = `${local.date}:${sessionName}`;
    if ((sessionSignalCounts.get(sessionKey) ?? 0) >= CONFIG.maxSignalsPerSession) {
      addRejection(setupId(fvg), "MAX_SESSION_SIGNALS_REACHED", fvg.direction, confirmationIndex, "REJECTED");
      return { confirmedIndex: null };
    }
    if ((daySignalCounts.get(local.date) ?? 0) >= CONFIG.maxSignalsPerDay) {
      addRejection(setupId(fvg), "MAX_DAILY_SIGNALS_REACHED", fvg.direction, confirmationIndex, "REJECTED");
      return { confirmedIndex: null };
    }

    const warnings = buildWarnings(fvg, retest, sessionName, target.fixed);
    const scoreParts = scoreSetup(candles, fvg, retest, confirmationIndex, rr);
    const bonus = (CONFIG.allowLiquiditySweepBonus && fvg.hasLiquiditySweep ? 5 : 0)
      + (CONFIG.allowOrderBlockBonus && fvg.hasOrderBlock ? 5 : 0)
      + (CONFIG.allowEmaTrendBonus && fvg.emaTrendAligned ? 5 : 0);
    const sessionPenalty = sessionName === "OFF_SESSION" ? 5 : 0;
    const score = Math.min(100, Math.max(0, Object.values(scoreParts).reduce((sum, value) => sum + value, 0) + bonus - sessionPenalty));
    if (score < CONFIG.minSignalScore) {
      addRejection(setupId(fvg), "SIGNAL_SCORE_TOO_LOW", fvg.direction, confirmationIndex, "REJECTED");
      return { confirmedIndex: null };
    }

    const signal = buildSignal({
      input,
      candles,
      fvg,
      retest,
      confirmationIndex,
      entry,
      stopLoss,
      target: target.price,
      risk,
      reward,
      rr,
      score,
      scoreParts,
      warnings,
      fixedTarget: target.fixed,
      sessionName,
      atr: confirmationAtr,
    });
    signals.push(signal);
    sessionSignalCounts.set(sessionKey, (sessionSignalCounts.get(sessionKey) ?? 0) + 1);
    daySignalCounts.set(local.date, (daySignalCounts.get(local.date) ?? 0) + 1);
    candidateDebug.push(makeDebug(setupId(fvg), fvg.direction, "CONFIRMED", "CONFIRMED_SIGNAL", 0, "CONFIRMED_SIGNAL", score, rr));
    return { confirmedIndex: confirmationIndex };
  }

  function addRejection(setupIdValue: string, code: SignalRejectionCode, direction: Direction, index: number, stage: Stage): void {
    increment(rejectionCounts, code);
    const debug = makeDebug(setupIdValue, direction, "REJECTED", code, 0, stage);
    candidateDebug.push(debug);
    rejectedSetups.push(toRejected(setupIdValue, direction, index, code, debug));
  }

  const generationTimeMs = performance.now() - started;
  const topRejectionReasons = rejectionRows(rejectionCounts);
  const audit = makeAudit({
    candles: candles.length,
    signals,
    rejectedSetups,
    pendingCandidates,
    generationTimeMs,
    displacementsFound,
    structureBreaksConfirmed,
    fvgsCreated,
    validFvgs,
    fvgRetestsFound,
    confirmationCandlesFound,
    expiredSetups,
    topRejectionReasons,
    candidateDebug,
  });

  const result: EntryEngineResult = {
    signals,
    activeSignals: signals,
    signalMap: new Map(signals.map((signal) => [signal.id, signal])),
    pendingCandidates,
    candidateDebug,
    rejectedSetups,
    noTrade: signals.length ? null : {
      status: "NO_TRADE",
      checkedSetups: validFvgs,
      rejectionReasons: topRejectionReasons.map((row) => row.reason),
      message: pendingCandidates.length ? "FVG continuation setup is still forming." : "No confirmed FVG continuation signal found.",
      nearestPossibleSetup: pendingCandidates.at(-1)?.setupId ?? null,
      requiredForSignal: ["Displacement", "BOS/CHoCH", "Valid FVG", "FVG retest", "Closed confirmation candle", "Minimum 1.5R"],
      timestamp: candles.at(-1)?.timestamp ?? null,
    },
    audit,
  };
  if (resultCache.size >= 50) resultCache.delete(resultCache.keys().next().value ?? "");
  resultCache.set(key, result);
  return result;
}

function detectDisplacement(candles: Candle[], index: number, atr: number): Displacement | null {
  const candle = candles[index];
  const range = candle.high - candle.low;
  if (range <= 0 || range < atr * CONFIG.minDisplacementRangeAtr) return null;
  const bodyRatio = Math.abs(candle.close - candle.open) / range;
  if (bodyRatio < CONFIG.displacementBodyRatio) return null;
  const closePosition = (candle.close - candle.low) / range;
  const direction: Direction | null = candle.close > candle.open && closePosition >= CONFIG.displacementClosePosition
    ? "BUY"
    : candle.close < candle.open && closePosition <= 1 - CONFIG.displacementClosePosition
      ? "SELL"
      : null;
  if (!direction) return null;
  const structureBreak = detectStructureBreak(candles, index, direction);
  if (CONFIG.requireStructureBreak && !structureBreak) return null;
  return { direction, candleIndex: index, bodyRatio, closePosition, rangeAtrMultiple: range / atr, structureBreak: structureBreak ?? { type: "CHOCH", brokenLevel: candle.close } };
}

function detectStructureBreak(candles: Candle[], index: number, direction: Direction): StructureBreak | null {
  const start = Math.max(CONFIG.swingLookback, index - CONFIG.structureLookback);
  const end = index - CONFIG.swingLookback;
  const levels: number[] = [];
  for (let cursor = start; cursor <= end; cursor++) {
    if (direction === "BUY" && detectSwingHigh(candles, cursor, CONFIG.swingLookback)) levels.push(candles[cursor].high);
    if (direction === "SELL" && detectSwingLow(candles, cursor, CONFIG.swingLookback)) levels.push(candles[cursor].low);
  }
  if (!levels.length) {
    const fallback = candles.slice(Math.max(0, index - CONFIG.structureLookback), index);
    if (fallback.length < CONFIG.swingLookback) return null;
    levels.push(direction === "BUY" ? Math.max(...fallback.map((candle) => candle.high)) : Math.min(...fallback.map((candle) => candle.low)));
  }
  const level = direction === "BUY" ? Math.max(...levels) : Math.min(...levels);
  const candle = candles[index];
  const closedBreak = direction === "BUY" ? candle.close > level : candle.close < level;
  const wickBreak = direction === "BUY" ? candle.high > level : candle.low < level;
  if (closedBreak) return { type: "BOS", brokenLevel: level };
  if (CONFIG.allowChoChInsteadOfBOS && wickBreak) return { type: "CHOCH", brokenLevel: level };
  return null;
}

function touchesFvg(candle: Candle, fvg: FvgSetup, atr: number): boolean {
  const tolerance = atr * CONFIG.retestToleranceAtr;
  return candle.low <= fvg.top + tolerance && candle.high >= fvg.bottom - tolerance;
}

function fvgInvalidated(candle: Candle, fvg: FvgSetup, atr: number): boolean {
  const tolerance = atr * CONFIG.retestToleranceAtr;
  return fvg.direction === "BUY"
    ? candle.close < fvg.bottom - tolerance
    : candle.close > fvg.top + tolerance;
}

function makeRetest(candle: Candle, fvg: FvgSetup, candleIndex: number): Retest {
  const retestPrice = fvg.direction === "BUY"
    ? Math.max(fvg.bottom, Math.min(candle.low, fvg.top))
    : Math.max(fvg.bottom, Math.min(candle.high, fvg.top));
  const size = Math.max(fvg.top - fvg.bottom, Number.EPSILON);
  const depth = fvg.direction === "BUY"
    ? ((fvg.top - retestPrice) / size) * 100
    : ((retestPrice - fvg.bottom) / size) * 100;
  const touchedZone = depth >= 50 ? "MIDPOINT" : fvg.direction === "BUY" ? "TOP" : "BOTTOM";
  return {
    candleIndex,
    retestPrice,
    touchedZone,
    retestDepthPercent: Math.round(depth * 10) / 10,
  };
}

function isConfirmation(candle: Candle, atr: number, direction: Direction, fvg: FvgSetup): boolean {
  const range = candle.high - candle.low;
  if (range <= 0 || range < atr * CONFIG.minConfirmationRangeAtr) return false;
  const bodyRatio = Math.abs(candle.close - candle.open) / range;
  const closePosition = (candle.close - candle.low) / range;
  if (bodyRatio < CONFIG.confirmationBodyRatio) return false;
  return direction === "BUY"
    ? candle.close > candle.open && closePosition >= CONFIG.confirmationClosePosition && candle.close > fvg.midpoint
    : candle.close < candle.open && closePosition <= 1 - CONFIG.confirmationClosePosition && candle.close < fvg.midpoint;
}

function isDirectionalCandle(candle: Candle, direction: Direction): boolean {
  return direction === "BUY" ? candle.close > candle.open : candle.close < candle.open;
}

function findTarget(candles: Candle[], index: number, direction: Direction, entry: number, risk: number): { price: number; fixed: boolean } {
  const candidates: number[] = [];
  for (let cursor = Math.max(CONFIG.swingLookback, index - 80); cursor <= index - CONFIG.swingLookback; cursor++) {
    if (direction === "BUY" && detectSwingHigh(candles, cursor, CONFIG.swingLookback) && candles[cursor].high > entry) candidates.push(candles[cursor].high);
    if (direction === "SELL" && detectSwingLow(candles, cursor, CONFIG.swingLookback) && candles[cursor].low < entry) candidates.push(candles[cursor].low);
  }
  const previousSession = previousSessionTarget(candles, index, direction, entry);
  if (previousSession !== null) candidates.push(previousSession);
  if (candidates.length) return { price: direction === "BUY" ? Math.min(...candidates) : Math.max(...candidates), fixed: false };
  return { price: direction === "BUY" ? entry + risk * CONFIG.preferredRR : entry - risk * CONFIG.preferredRR, fixed: true };
}

function previousSessionTarget(candles: Candle[], index: number, direction: Direction, entry: number): number | null {
  const current = zonedDateParts(candles[index].timestamp, SESSION_TIMEZONE).date;
  const previous = candles.slice(Math.max(0, index - 288), index).filter((candle) => zonedDateParts(candle.timestamp, SESSION_TIMEZONE).date < current);
  if (previous.length < 3) return null;
  const level = direction === "BUY" ? Math.max(...previous.map((candle) => candle.high)) : Math.min(...previous.map((candle) => candle.low));
  return direction === "BUY" ? level > entry ? level : null : level < entry ? level : null;
}

function hasLiquiditySweepBeforeDisplacement(candles: Candle[], displacementIndex: number, direction: Direction): boolean {
  const window = candles.slice(Math.max(0, displacementIndex - 8), displacementIndex);
  const prior = candles.slice(Math.max(0, displacementIndex - 24), Math.max(0, displacementIndex - 8));
  if (window.length < 3 || prior.length < 3) return false;
  if (direction === "BUY") {
    const priorLow = Math.min(...prior.map((candle) => candle.low));
    return window.some((candle) => candle.low < priorLow && candle.close > priorLow);
  }
  const priorHigh = Math.max(...prior.map((candle) => candle.high));
  return window.some((candle) => candle.high > priorHigh && candle.close < priorHigh);
}

function hasOrderBlockNearFvg(candles: Candle[], displacementIndex: number, direction: Direction, fvgBottom: number, fvgTop: number): boolean {
  const start = Math.max(0, displacementIndex - 6);
  const size = Math.max(fvgTop - fvgBottom, Number.EPSILON);
  for (let index = displacementIndex - 1; index >= start; index--) {
    const candle = candles[index];
    const opposite = direction === "BUY" ? candle.close < candle.open : candle.close > candle.open;
    if (!opposite) continue;
    return candle.high >= fvgBottom - size * 2 && candle.low <= fvgTop + size * 2;
  }
  return false;
}

function emaTrendAligned(ema20: Array<number | null>, ema50: Array<number | null>, ema200: Array<number | null>, index: number, direction: Direction): boolean {
  const fast = ema20[index];
  const mid = ema50[index];
  const slow = ema200[index];
  if (fast === null || mid === null || slow === null) return false;
  return direction === "BUY" ? fast >= mid && mid >= slow : fast <= mid && mid <= slow;
}

function scoreSetup(candles: Candle[], fvg: FvgSetup, retest: Retest, confirmationIndex: number, rr: number): ScoreParts {
  const confirmation = candles[confirmationIndex];
  const range = confirmation.high - confirmation.low;
  const bodyRatio = range > 0 ? Math.abs(confirmation.close - confirmation.open) / range : 0;
  const closePosition = range > 0 ? (confirmation.close - confirmation.low) / range : 0.5;
  const directionalClose = fvg.direction === "BUY" ? closePosition : 1 - closePosition;
  return {
    displacementQuality: Math.min(25, Math.round(12 + fvg.displacement.bodyRatio * 7 + Math.min(6, fvg.displacement.rangeAtrMultiple * 2))),
    structureBreakQuality: fvg.displacement.structureBreak.type === "BOS" ? 15 : 12,
    fvgQuality: Math.min(20, fvg.sizeAtr <= 0.7 ? 20 : fvg.sizeAtr <= 1.2 ? 17 : 14),
    retestQuality: Math.min(15, Math.round(9 + Math.min(6, retest.retestDepthPercent / 10))),
    confirmationQuality: Math.min(15, Math.round(5 + bodyRatio * 5 + directionalClose * 5)),
    rrQuality: Math.min(10, Math.round(7 + Math.min(3, (rr - CONFIG.minRR) * 2))),
  };
}

function buildWarnings(fvg: FvgSetup, retest: Retest, sessionName: string, fixedTarget: boolean): string[] {
  const warnings = new Set<string>();
  if (sessionName === "OFF_SESSION") warnings.add("OUTSIDE_ACTIVE_SESSION");
  if (retest.retestDepthPercent < 50) warnings.add("FVG_RETEST_NOT_AT_MIDPOINT");
  if (fixedTarget) {
    warnings.add("TARGET_USING_FIXED_RR");
    warnings.add("NO_LIQUIDITY_TARGET_FOUND");
  }
  if (!fvg.hasOrderBlock) warnings.add("NO_ORDER_BLOCK_CONFLUENCE");
  if (!fvg.hasLiquiditySweep) warnings.add("NO_LIQUIDITY_SWEEP_CONFLUENCE");
  if (!fvg.emaTrendAligned) warnings.add("EMA_TREND_NOT_ALIGNED");
  return [...warnings];
}

function buildSignal(args: {
  input: V2GoldmineInput;
  candles: Candle[];
  fvg: FvgSetup;
  retest: Retest;
  confirmationIndex: number;
  entry: number;
  stopLoss: number;
  target: number;
  risk: number;
  reward: number;
  rr: number;
  score: number;
  scoreParts: ScoreParts;
  warnings: string[];
  fixedTarget: boolean;
  sessionName: string;
  atr: number;
}): TradeSignal {
  const confirmation = args.candles[args.confirmationIndex];
  const displacement = args.candles[args.fvg.displacementIndex];
  const retestCandle = args.candles[args.retest.candleIndex];
  const range = confirmation.high - confirmation.low;
  const bodyRatio = range > 0 ? Math.abs(confirmation.close - confirmation.open) / range : 0;
  const closePosition = range > 0 ? (confirmation.close - confirmation.low) / range : 0;
  const scoreBreakdown: SignalScoreBreakdown = {
    phase4Setup: args.scoreParts.displacementQuality + args.scoreParts.structureBreakQuality,
    contextAlignment: args.scoreParts.fvgQuality,
    confirmationCandle: args.scoreParts.confirmationQuality,
    stopLossQuality: args.scoreParts.retestQuality,
    targetQuality: args.scoreParts.rrQuality,
    sessionQuality: args.sessionName === "OFF_SESSION" ? 0 : 5,
    volatilityQuality: 0,
    antiReversal: 0,
  };
  return {
    id: `${FVG_CONTINUATION_ENTRY_STRATEGY_ID}:${args.input.symbol}:${confirmation.timestamp}:${args.fvg.direction}`,
    engine: ACTIVE_SIGNAL_ENGINE,
    strategyId: FVG_CONTINUATION_ENTRY_STRATEGY_ID,
    v2Direction: args.fvg.direction,
    type: args.fvg.direction === "BUY" ? "CONFIRMED_BUY" : "CONFIRMED_SELL",
    direction: args.fvg.direction === "BUY" ? "BULLISH" : "BEARISH",
    status: "CONFIRMED",
    sourceSetupId: setupId(args.fvg),
    setupType: "TREND_CONTINUATION",
    strategyModel: FVG_CONTINUATION_ENTRY_STRATEGY_LABEL,
    mode: "V2_DEFAULT",
    timestamp: confirmation.timestamp,
    candleIndex: args.confirmationIndex,
    confirmedAtIndex: args.confirmationIndex,
    timeframe: args.input.timeframe,
    session: toTradingSession(args.sessionName),
    entryPrice: round(args.entry),
    stopLoss: round(args.stopLoss),
    takeProfit: round(args.target),
    takeProfit2: null,
    takeProfit3: null,
    riskPoints: round(args.risk),
    rewardPoints: round(args.reward),
    rr: round(args.rr, 3),
    score: args.score,
    confidence: confidenceFor(args.score),
    positionSizeSuggestion: round((args.input.settings?.maxRiskAmount ?? 100) / args.risk, 4),
    maxRiskAmount: args.input.settings?.maxRiskAmount ?? 100,
    invalidationLevel: round(args.stopLoss),
    reasons: [
      `${args.fvg.direction.toLowerCase()} displacement broke ${args.fvg.displacement.structureBreak.type} at ${args.fvg.displacement.structureBreak.brokenLevel.toFixed(2)}.`,
      `${args.fvg.type} formed and price retested the imbalance.`,
      "A closed confirmation candle continued from the FVG.",
    ],
    warnings: args.warnings,
    rejectionReasons: [],
    relatedMarkers: [],
    noRepaintProof: {
      status: "PASS",
      signalIndex: args.confirmationIndex,
      latestAllowedCandleIndex: args.confirmationIndex,
      usedMarkerIndexes: [args.fvg.displacementIndex, args.fvg.createdAtIndex, args.retest.candleIndex, args.confirmationIndex],
      usedContextCloseTimes: [],
      usedSetupId: setupId(args.fvg),
      passed: true,
      lastAvailableIndex: args.confirmationIndex,
      maxEvidenceIndex: args.confirmationIndex,
      message: "FVG continuation signal uses only closed candles through retest and confirmation; entry, SL, TP, and RR are immutable.",
    },
    stopLossDetail: {
      price: round(args.stopLoss),
      source: "FVG_RETEST_ATR_BUFFER",
      buffer: round(args.atr * CONFIG.slAtrBuffer),
      riskPoints: round(args.risk),
      reason: "Stop is beyond the FVG/retest extreme and displacement origin with ATR buffer.",
    },
    takeProfitDetail: {
      tp1: round(args.target),
      tp2: null,
      tp3: null,
      source: args.fixedTarget ? "FIXED_2R_FALLBACK" : "RECENT_STRUCTURE_LIQUIDITY",
      rewardPoints: round(args.reward),
      reason: args.fixedTarget ? "No qualifying liquidity target was available; preferred fixed-RR target used." : "Nearest recent swing or previous-session liquidity target.",
    },
    scoreBreakdown,
    fvgContinuation: {
      stage: "CONFIRMED_SIGNAL",
      sessionName: args.sessionName,
      signalTime: confirmation.timestamp,
      displacement: {
        candleTime: displacement.timestamp,
        candleIndex: args.fvg.displacementIndex,
        direction: args.fvg.direction === "BUY" ? "BULLISH" : "BEARISH",
        open: displacement.open,
        high: displacement.high,
        low: displacement.low,
        close: displacement.close,
        bodyRatio: args.fvg.displacement.bodyRatio,
        closePosition: args.fvg.displacement.closePosition,
        rangeAtrMultiple: args.fvg.displacement.rangeAtrMultiple,
      },
      structureBreak: {
        type: args.fvg.displacement.structureBreak.type,
        brokenLevel: args.fvg.displacement.structureBreak.brokenLevel,
        confirmedAt: displacement.timestamp,
      },
      fvg: {
        type: args.fvg.type,
        createdAt: args.candles[args.fvg.createdAtIndex].timestamp,
        createdAtIndex: args.fvg.createdAtIndex,
        top: args.fvg.top,
        bottom: args.fvg.bottom,
        midpoint: args.fvg.midpoint,
        size: args.fvg.size,
        sizeAtr: args.fvg.sizeAtr,
        retestedAt: retestCandle.timestamp,
        retestedAtIndex: args.retest.candleIndex,
        retestDepthPercent: args.retest.retestDepthPercent,
        invalidated: false,
      },
      retest: {
        candleTime: retestCandle.timestamp,
        candleIndex: args.retest.candleIndex,
        retestPrice: args.retest.retestPrice,
        touchedZone: args.retest.touchedZone,
        held: true,
      },
      confirmation: {
        candleTime: confirmation.timestamp,
        open: confirmation.open,
        high: confirmation.high,
        low: confirmation.low,
        close: confirmation.close,
        bodyRatio,
        closePosition,
        rangeAtrMultiple: range / args.atr,
      },
      confluence: {
        hasLiquiditySweep: args.fvg.hasLiquiditySweep,
        hasOrderBlock: args.fvg.hasOrderBlock,
        emaTrendAligned: args.fvg.emaTrendAligned,
      },
    },
    immutable: true,
  };
}

function makeDebug(
  setupIdValue: string,
  direction: Direction,
  status: SignalCandidateDebug["confirmationStatus"],
  reason: string,
  remaining: number,
  stage: Stage,
  score: number | null = null,
  rr: number | null = null,
): SignalCandidateDebug {
  return {
    setupId: setupIdValue,
    engine: ACTIVE_SIGNAL_ENGINE,
    strategyId: FVG_CONTINUATION_ENTRY_STRATEGY_ID,
    setupScore: 0,
    requiredSetupScore: 0,
    finalSignalScore: score,
    requiredSignalScore: CONFIG.minSignalScore,
    signalScore: score,
    rr,
    requiredRR: CONFIG.minRR,
    directionBias: direction === "BUY" ? "BULLISH" : "BEARISH",
    confirmationStatus: status,
    confirmationWindowRemaining: remaining,
    rejectionReason: reason,
    nextRequiredAction: stage === "WAITING_FVG_RETEST"
      ? "Wait for price to return to the FVG."
      : stage === "WAITING_CONFIRMATION"
        ? "Wait for a closed confirmation candle from the FVG."
        : stage === "CONFIRMED_SIGNAL"
          ? "Use immutable trade levels."
          : "Wait for a new displacement, structure break, and FVG.",
    failedStage: stage,
  };
}

function toRejected(setupIdValue: string, direction: Direction, index: number, code: SignalRejectionCode, debug: SignalCandidateDebug, state: RejectedSetup["setupState"] = "INVALIDATED"): RejectedSetup {
  return {
    setupId: setupIdValue,
    setupType: "TREND_CONTINUATION",
    setupState: state,
    direction: direction === "BUY" ? "BULLISH" : "BEARISH",
    triggerIndex: index,
    rejectionReasons: [code],
    rejectionReasonCodes: [code],
    debug,
  };
}

function makeAudit(args: {
  candles: number;
  signals: TradeSignal[];
  rejectedSetups: RejectedSetup[];
  pendingCandidates: SignalCandidateDebug[];
  generationTimeMs: number;
  displacementsFound: number;
  structureBreaksConfirmed: number;
  fvgsCreated: number;
  validFvgs: number;
  fvgRetestsFound: number;
  confirmationCandlesFound: number;
  expiredSetups: number;
  topRejectionReasons: Array<{ reason: string; count: number; percentage: number }>;
  candidateDebug: SignalCandidateDebug[];
}): EntryEngineResult["audit"] {
  return {
    activeEngine: ACTIVE_SIGNAL_ENGINE,
    strategyId: FVG_CONTINUATION_ENTRY_STRATEGY_ID,
    activeMode: "V2_DEFAULT",
    minimumScoreRequired: CONFIG.minSignalScore,
    minimumSetupScoreRequired: 0,
    minimumSignalScoreRequired: CONFIG.minSignalScore,
    minimumRrRequired: CONFIG.minRR,
    totalCandlesScanned: args.candles,
    totalMarkersGenerated: 0,
    totalContextsGenerated: 0,
    totalPhase4Setups: 0,
    watchCount: args.pendingCandidates.length,
    setupCount: args.validFvgs,
    invalidatedCount: args.rejectedSetups.length,
    expiredCount: args.expiredSetups,
    totalSetupsScanned: args.fvgsCreated,
    triggerSetupsFound: args.fvgRetestsFound,
    pendingConfirmationCount: args.pendingCandidates.length,
    expiredConfirmationCount: args.expiredSetups,
    invalidatedCandidateCount: args.rejectedSetups.length,
    confirmedBuyCount: args.signals.filter((signal) => signal.direction === "BULLISH").length,
    confirmedSellCount: args.signals.filter((signal) => signal.direction === "BEARISH").length,
    rapidBuyCount: 0,
    rapidSellCount: 0,
    rapidSignalCount: 0,
    rejectedSetupCount: args.rejectedSetups.length,
    lastRejectionReason: args.rejectedSetups.at(-1)?.rejectionReasons[0] ?? null,
    lastConfirmedSignal: args.signals.at(-1)?.id ?? null,
    topRejectionReasons: args.topRejectionReasons.map(({ reason, count }) => ({ reason, count })),
    lastFiveTriggerSetups: args.candidateDebug.slice(-5).map((item) => item.setupId),
    lastFiveConfirmedSignals: args.signals.slice(-5).map((signal) => signal.id),
    noSignalMessage: args.signals.length ? null : "No confirmed FVG continuation signal.",
    noRepaintWarnings: [],
    rrCalculation: args.signals.at(-1) ? `${args.signals.at(-1)!.rr.toFixed(2)}R` : null,
    stopLossSource: args.signals.at(-1)?.stopLossDetail.source ?? null,
    takeProfitSource: args.signals.at(-1)?.takeProfitDetail.source ?? null,
    scoreBreakdown: args.signals.at(-1)?.scoreBreakdown ?? null,
    lastCandidateDebug: args.candidateDebug.at(-1) ?? null,
    noRepaintValidation: "PASS",
    calculationTimeMs: args.generationTimeMs,
    generationTimeMs: args.generationTimeMs,
    cacheStatus: "miss",
    v2FvgContinuation: {
      activeEngineLabel: FVG_CONTINUATION_ENTRY_STRATEGY_LABEL,
      strategyId: FVG_CONTINUATION_ENTRY_STRATEGY_ID,
      candlesScanned: args.candles,
      displacementsFound: args.displacementsFound,
      structureBreaksConfirmed: args.structureBreaksConfirmed,
      fvgsCreated: args.fvgsCreated,
      validFvgs: args.validFvgs,
      fvgRetestsFound: args.fvgRetestsFound,
      confirmationCandlesFound: args.confirmationCandlesFound,
      confirmedSignals: args.signals.length,
      rejectedSignals: args.rejectedSetups.length,
      expiredSetups: args.expiredSetups,
      generationTimeMs: args.generationTimeMs,
      topRejectionReasons: args.topRejectionReasons,
    },
  };
}

function setupId(fvg: FvgSetup): string {
  return `fvg-continuation:${fvg.createdAtIndex}:${fvg.direction}:${fvg.bottom}:${fvg.top}`;
}

function setupIdFromDisplacement(candles: Candle[], displacement: Displacement): string {
  return `fvg-continuation:${candles[displacement.candleIndex].timestamp}:${displacement.direction}`;
}

function sessionNameAt(timestamp: number): string {
  for (const session of CONFIG.allowedSessions) {
    const name = clockWindowAt(timestamp, session.timezone, [{ name: session.name, start: session.start, end: session.end }]);
    if (name) return name;
  }
  return "OFF_SESSION";
}

function toTradingSession(session: string): TradingSession {
  if (session === "LONDON") return "LONDON";
  if (session === "OVERLAP") return "LONDON_NEW_YORK_OVERLAP";
  if (session === "NY_AM") return "NEW_YORK";
  return "DEAD_ZONE";
}

function rejectionRows(counts: Map<string, number>) {
  const total = [...counts.values()].reduce((sum, count) => sum + count, 0);
  return [...counts.entries()]
    .map(([reason, count]) => ({ reason, count, percentage: total ? Math.round((count / total) * 1000) / 10 : 0 }))
    .sort((a, b) => b.count - a.count || a.reason.localeCompare(b.reason));
}

function increment(map: Map<string, number>, key: string): void {
  map.set(key, (map.get(key) ?? 0) + 1);
}

function cloneResult(result: EntryEngineResult, cacheStatus: "hit" | "miss"): EntryEngineResult {
  return { ...result, signalMap: new Map(result.signalMap), audit: { ...result.audit, cacheStatus } };
}

function confidenceFor(score: number): TradeSignal["confidence"] {
  return score >= 90 ? "PREMIUM" : score >= 78 ? "STRONG" : score >= 65 ? "MODERATE" : "LOW_CONFIRMED";
}

function round(value: number, digits = 5): number {
  const factor = 10 ** digits;
  return Math.round((value + Number.EPSILON) * factor) / factor;
}
